// 📁 patientchart-actions.js – Full Permission-Driven Action Handlers for Patient Charts
import {
  showToast,
  showConfirm,
  openViewModal,
  showLoading,
  hideLoading,
} from "../../utils/index.js";
import { authFetch } from "../../authSession.js";
import { renderCard } from "./patientchart-render.js";

/**
 * Unified, permission-driven action handler for Patient Chart module
 * Mirrors consultation-actions.js / centralstock-actions.js (enterprise standard)
 */
export function setupActionHandlers({
  entries,
  token,
  currentPage,
  loadEntries,
  visibleFields,
  sharedState,
  user, // ✅ { role, permissions }
}) {
  const { currentEditIdRef } = sharedState || {};
  const tableBody = document.getElementById("patientChartTableBody");
  const cardContainer = document.getElementById("patientChartList");

  // cache latest entries globally for quick lookup
  window.latestPatientChartEntries = entries;

  if (tableBody) tableBody.addEventListener("click", handleActions);
  if (cardContainer) cardContainer.addEventListener("click", handleActions);

  /* ---------------------- Normalize permissions ---------------------- */
  function normalizePermissions(perms) {
    if (!perms) return [];
    if (typeof perms === "string") {
      try {
        return JSON.parse(perms);
      } catch {
        return perms.split(",").map((p) => p.trim());
      }
    }
    return Array.isArray(perms) ? perms : [];
  }

  const userPerms = new Set(normalizePermissions(user?.permissions || []));

  // ✅ Super Admin bypass
  const isSuperAdmin =
    (user?.role && user.role.toLowerCase().replace(/\s+/g, "") === "superadmin") ||
    (Array.isArray(user?.roleNames) &&
      user.roleNames.some(
        (r) => r.toLowerCase().replace(/\s+/g, "") === "superadmin"
      ));

  // ✅ Unified permission checker
  const hasPerm = (key) => {
    const normalizedKey = key.trim().toLowerCase();
    return isSuperAdmin || userPerms.has(normalizedKey);
  };

  /* ---------------------- Handler dispatcher ---------------------- */
  async function handleActions(e) {
    const btn = e.target.closest("button");
    if (!btn || !btn.dataset.id) return;

    const id = btn.dataset.id;
    let entry =
      (window.latestPatientChartEntries || entries || []).find(
        (x) => String(x.patient_id || x.id) === String(id)
      ) || null;

    // fallback fetch if missing
    if (!entry) {
      try {
        showLoading();
        const res = await authFetch(`/api/patient-chart/patient/${id}`);
        const data = await res.json().catch(() => ({}));
        entry = data?.data;
      } catch {
        return showToast("❌ Patient chart not found");
      } finally {
        hideLoading();
      }
    }

    if (!entry) return showToast("❌ Patient chart data missing");
    const cls = btn.classList;

    // --- View full chart ---
    if (cls.contains("view-btn")) {
      if (!hasPerm("patient_charts:view"))
        return showToast("⛔ You don't have permission to view charts");
      return handleView(entry);
    }

    // --- View summary ---
    if (cls.contains("summary-btn")) {
      if (!hasPerm("patient_charts:summary"))
        return showToast("⛔ You don't have permission to view summary");
      return handleSummary(entry);
    }

    // --- Refresh / Revalidate cache ---
    if (cls.contains("refresh-btn")) {
      if (!hasPerm("patient_charts:invalidate_cache"))
        return showToast("⛔ You don't have permission to refresh cache");
      return await handleCacheRevalidate(id);
    }

    // --- Delete cache entry (admin only) ---
    if (cls.contains("delete-btn")) {
      if (!hasPerm("patient_charts:invalidate_cache"))
        return showToast("⛔ You don't have permission to delete cache");
      return await handleCacheDelete(id);
    }

    // --- Open notes section ---
    if (cls.contains("notes-btn")) {
      if (!hasPerm("patient_chart_notes:view"))
        return showToast("⛔ You don't have permission to view notes");
      return handleViewNotes(entry);
    }
  }

  /* ---------------------- Handlers ---------------------- */
  function handleView(entry) {
    const html = renderCard(entry, visibleFields, user);
    openViewModal("Patient Chart", html);
  }

  async function handleSummary(entry) {
    try {
      showLoading();
      const res = await authFetch(
        `/api/patient-chart/patient/${entry.patient_id || entry.id}/summary`
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.message || "Failed to load summary");
      openViewModal("Patient Chart Summary", JSON.stringify(data.data, null, 2));
    } catch (err) {
      console.error(err);
      showToast(err.message || "❌ Failed to fetch summary");
    } finally {
      hideLoading();
    }
  }

  async function handleCacheRevalidate(patientId) {
    const confirmed = await showConfirm("Revalidate this patient's chart cache?");
    if (!confirmed) return;

    try {
      showLoading();
      const res = await authFetch(
        `/api/patient-chart/patient/${patientId}/cache/invalidate`,
        { method: "POST" }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok)
        throw new Error(data.message || "❌ Failed to revalidate cache");

      showToast(`✅ Cache revalidation triggered`);
      await loadEntries(currentPage);
    } catch (err) {
      console.error(err);
      showToast(err.message || "❌ Failed to revalidate cache");
    } finally {
      hideLoading();
    }
  }

  async function handleCacheDelete(patientId) {
    const confirmed = await showConfirm("Delete this patient's chart cache?");
    if (!confirmed) return;

    try {
      showLoading();
      // 🚀 Adjusted: backend uses same POST invalidate endpoint
      const res = await authFetch(
        `/api/patient-chart/patient/${patientId}/cache/invalidate`,
        { method: "POST" }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok)
        throw new Error(data.message || "❌ Failed to delete chart cache");

      showToast(`✅ Chart cache invalidated`);
      await loadEntries(currentPage);
    } catch (err) {
      console.error(err);
      showToast(err.message || "❌ Failed to delete cache");
    } finally {
      hideLoading();
    }
  }

  function handleViewNotes(entry) {
    sessionStorage.setItem("patientChartId", entry.patient_id || entry.id);
    window.location.href = `/pages/patientchartnote.html?patient_id=${
      entry.patient_id || entry.id
    }`;
  }

  /* ---------------------- Global helpers ---------------------- */
  const findEntry = (id) =>
    (window.latestPatientChartEntries || entries || []).find(
      (x) => String(x.patient_id || x.id) === String(id)
    );

  window.viewChart = (id) => {
    if (!hasPerm("patient_charts:view"))
      return showToast("⛔ No permission to view chart");
    const entry = findEntry(id);
    if (entry) handleView(entry);
    else showToast("❌ Chart not found for viewing");
  };

  window.viewSummary = async (id) => {
    if (!hasPerm("patient_charts:summary"))
      return showToast("⛔ No permission to view summary");
    const entry = findEntry(id);
    if (entry) await handleSummary(entry);
    else showToast("❌ Chart not found for summary");
  };

  window.refreshCache = async (id) => {
    if (!hasPerm("patient_charts:invalidate_cache"))
      return showToast("⛔ No permission to revalidate cache");
    await handleCacheRevalidate(id);
  };

  window.openNotes = (id) => {
    if (!hasPerm("patient_chart_notes:view"))
      return showToast("⛔ No permission to view notes");
    const entry = findEntry(id);
    if (entry) handleViewNotes(entry);
  };
}
