// 📦 patientchart-form.js – Secure & Role-Aware Patient Chart Form (Enterprise-Aligned)

import {
  showToast,
  showLoading,
  hideLoading,
  initPageGuard,
  autoPagePermissionKey,
  initLogoutWatcher,
} from "../../utils/index.js";
import { authFetch } from "../../authSession.js";
import {
  loadOrganizationsLite,
  loadFacilitiesLite,
  loadPatientsLite,
  setupSelectOptions,
  setupSuggestionInputDynamic,
} from "../../utils/data-loaders.js";

/* ============================================================
   🔧 Helpers
============================================================ */
function normalizeMessage(result, fallback) {
  if (!result) return fallback;
  const msg = result.message ?? result.error ?? result.msg;
  if (typeof msg === "string") return msg;
  if (msg?.detail) return msg.detail;
  try {
    return JSON.stringify(msg);
  } catch {
    return fallback;
  }
}

function normalizeUUID(val) {
  return val && val.trim() !== "" ? val : null;
}

/* ============================================================
   🚀 Setup Patient Chart Form Submission
============================================================ */
export async function setupPatientChartFormSubmission({ form, sharedState }) {
  // 🔐 Auth Guard
  const token = initPageGuard(autoPagePermissionKey());
  initLogoutWatcher();

  const sessionId = sessionStorage.getItem("patientChartEditId");
  const isEdit = !!sessionId;

  const titleEl = document.querySelector(".card-title");
  const submitBtn = form?.querySelector("button[type=submit]");
  const cancelBtn = document.getElementById("cancelBtn");
  const clearBtn = document.getElementById("clearBtn");

  const setUI = (mode = "add") => {
    if (mode === "edit") {
      titleEl && (titleEl.textContent = "Edit Patient Chart Cache");
      submitBtn &&
        (submitBtn.innerHTML = `<i class="ri-save-3-line me-1"></i> Update Cache`);
    } else {
      titleEl && (titleEl.textContent = "Generate Patient Chart Cache");
      submitBtn &&
        (submitBtn.innerHTML = `<i class="ri-add-line me-1"></i> Generate Cache`);
    }
  };
  setUI(isEdit ? "edit" : "add");

  /* ============================================================
     🧭 Prefill Dropdowns & Suggestions
  ============================================================ */
  const orgSelect = document.getElementById("organizationSelect");
  const facSelect = document.getElementById("facilitySelect");
  const patientInput = document.getElementById("patientInput");
  const patientHidden = document.getElementById("patientId");
  const patientSuggestions = document.getElementById("patientSuggestions");
  const statusSelect = document.getElementById("statusSelect");

  let userRole = (localStorage.getItem("userRole") || "").toLowerCase();

  try {
    // Organization & Facility scope setup
    if (userRole.includes("super")) {
      const orgs = await loadOrganizationsLite();
      setupSelectOptions(orgSelect, orgs, "id", "name", "-- Select Organization --");

      async function reloadFacilities(orgId = null) {
        const facs = await loadFacilitiesLite(orgId ? { organization_id: orgId } : {}, true);
        setupSelectOptions(facSelect, facs, "id", "name", "-- Select Facility --");
      }

      await reloadFacilities();
      orgSelect?.addEventListener("change", async () => {
        await reloadFacilities(orgSelect.value || null);
      });
    } else if (userRole.includes("admin")) {
      orgSelect?.closest(".form-group")?.classList.add("hidden");
      const facs = await loadFacilitiesLite({}, true);
      setupSelectOptions(facSelect, facs, "id", "name", "-- Select Facility --");
    } else {
      orgSelect?.closest(".form-group")?.classList.add("hidden");
      facSelect?.closest(".form-group")?.classList.add("hidden");
    }

    // ✅ Patient suggestions
    setupSuggestionInputDynamic(
      patientInput,
      patientSuggestions,
      "/api/lite/patients",
      (selected) => {
        patientHidden.value = selected?.id || "";
        patientInput.value =
          selected.label ||
          (selected.pat_no && selected.full_name
            ? `${selected.pat_no} - ${selected.full_name}`
            : selected.full_name || selected.pat_no || "");
      },
      "label"
    );
  } catch (err) {
    console.error("❌ Dropdown preload failed:", err);
    showToast("❌ Failed to load reference lists");
  }

  /* ============================================================
     ✏️ Prefill if Editing Existing Cache
  ============================================================ */
  if (isEdit && sessionId) {
    try {
      showLoading();
      const res = await authFetch(`/api/patient-chart/patient/${sessionId}/cache`);
      const result = await res.json().catch(() => ({}));
      hideLoading();

      if (!res.ok) throw new Error(normalizeMessage(result, "Failed to load cache"));
      const entry = result?.data;
      if (!entry) return;

      if (entry.organization) orgSelect.value = entry.organization.id || "";
      if (entry.facility) facSelect.value = entry.facility.id || "";
      if (entry.patient) {
        patientHidden.value = entry.patient.id || "";
        patientInput.value =
          entry.patient.pat_no && entry.patient.full_name
            ? `${entry.patient.pat_no} - ${entry.patient.full_name}`
            : entry.patient.full_name || entry.patient.pat_no || "";
      }
      if (statusSelect) statusSelect.value = entry.status || "active";
    } catch (err) {
      hideLoading();
      console.error("❌ Prefill error:", err);
      showToast(err.message || "❌ Could not load chart cache");
    }
  }

  /* ============================================================
     💾 Submit Handler (Regenerate Cache)
  ============================================================ */
  form.onsubmit = async (e) => {
    e.preventDefault();
    if (!e.isTrusted) return;

    const patientId = normalizeUUID(patientHidden.value);
    if (!patientId) return showToast("❌ Patient is required");

    try {
      showLoading();

      // POST → manually invalidate cache (auto-regeneration handled backend)
      const res = await authFetch(
        `/api/patient-chart/patient/${patientId}/cache/invalidate`,
        { method: "POST" }
      );

      const result = await res.json().catch(() => ({}));
      if (!res.ok)
        throw new Error(normalizeMessage(result, `❌ Server error (${res.status})`));

      showToast("✅ Chart cache revalidation started successfully");
      sessionStorage.removeItem("patientChartEditId");
      sessionStorage.removeItem("patientChartEditPayload");

      form.reset();
      setUI("add");
    } catch (err) {
      console.error("❌ Submission error:", err);
      showToast(err.message || "❌ Submission error");
    } finally {
      hideLoading();
    }
  };

  /* ============================================================
     🚪 Cancel / Clear
  ============================================================ */
  cancelBtn?.addEventListener("click", () => {
    sessionStorage.removeItem("patientChartEditId");
    sessionStorage.removeItem("patientChartEditPayload");
    window.location.href = "/patientchart-list.html";
  });

  clearBtn?.addEventListener("click", () => {
    sessionStorage.removeItem("patientChartEditId");
    sessionStorage.removeItem("patientChartEditPayload");
    form.reset();
    setUI("add");
  });
}
