// 📦 patientchart-main.js – Form-only loader for Patient Chart (Enterprise Pattern)

import {
  initPageGuard,
  autoPagePermissionKey,
  initLogoutWatcher,
} from "../../utils/index.js";
import { setupPatientChartFormSubmission } from "./patientchart-form.js";
import {
  FIELD_LABELS_PATIENT_CHART_CACHE,
  FIELD_ORDER_PATIENT_CHART_CACHE,
  FIELD_DEFAULTS_PATIENT_CHART_CACHE,
} from "./patientchart-constants.js";
import { setupFieldSelector } from "../../utils/ui-utils.js";

/* ============================================================
   🔐 Auth + Global Guards
============================================================ */

// Automatically resolves correct permission ("patient_charts:create" / "patient_charts:edit")
const token = initPageGuard(autoPagePermissionKey());
initLogoutWatcher();

/* ============================================================
   🌐 Shared State
============================================================ */
const sharedState = {
  currentEditIdRef: { value: null },
};

/* ============================================================
   📎 DOM Refs
============================================================ */
const form = document.getElementById("patientChartForm");
const formContainer = document.getElementById("formContainer");
const desktopAddBtn = document.getElementById("desktopAddBtn");
const cancelBtn = document.getElementById("cancelBtn");
const clearBtn = document.getElementById("clearBtn");

/* ============================================================
   🧹 Reset Form Helper
============================================================ */
function resetForm() {
  sharedState.currentEditIdRef.value = null;
  if (form) form.reset();

  // Clear cached edit session
  sessionStorage.removeItem("patientChartEditId");
  sessionStorage.removeItem("patientChartEditPayload");

  // Clear fields and selects (if used in this module)
  [
    "organizationSelect",
    "facilitySelect",
    "patientInput",
    "statusSelect",
  ].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.value = "";
  });

  // Reset hidden fields
  const patientId = document.getElementById("patientId");
  if (patientId) patientId.value = "";

  // Clear snapshot display if any
  const snapshotPreview = document.getElementById("chartSnapshotPreview");
  if (snapshotPreview) snapshotPreview.innerHTML = "";
}

/* ============================================================
   🧭 Form Visibility
============================================================ */
function showForm() {
  formContainer?.classList.remove("hidden");
  desktopAddBtn?.classList.add("hidden");
  localStorage.setItem("patientChartFormVisible", "true");
}

function hideForm() {
  resetForm();
  formContainer?.classList.add("hidden");
  desktopAddBtn?.classList.remove("hidden");
  localStorage.setItem("patientChartFormVisible", "false");
}

window.showForm = showForm;
window.resetForm = resetForm;

/* ============================================================
   🔘 Button Wiring
============================================================ */
if (cancelBtn) {
  cancelBtn.onclick = () => {
    resetForm();
    window.location.href = "/patientchart-list.html"; // ✅ redirect to list view
  };
}

if (clearBtn) clearBtn.onclick = resetForm;

if (desktopAddBtn) {
  desktopAddBtn.onclick = () => {
    // Purge stale edit state
    sessionStorage.removeItem("patientChartEditId");
    sessionStorage.removeItem("patientChartEditPayload");

    // Reset & open form
    resetForm();
    showForm();
  };
}

/* ============================================================
   🧠 Loader (stub)
============================================================ */
async function loadEntries() {
  return; // list view handles entries if needed
}

/* ============================================================
   🚀 Module Initializer
============================================================ */
export async function initPatientChartModule() {
  showForm(); // auto-open form on standalone page

  setupPatientChartFormSubmission({
    form,
    token,
    sharedState,
    resetForm,
    loadEntries,
  });

  localStorage.setItem("patientChartPanelVisible", "false");

  // Normalize role for field defaults
  let roleRaw = localStorage.getItem("userRole") || "staff";
  let role = roleRaw.trim().toLowerCase();

  if (role.includes("super") && role.includes("admin")) role = "superadmin";
  else if (role.includes("admin")) role = "admin";
  else role = "staff";

  // 🧩 Initialize Field Selector (role-based)
  setupFieldSelector({
    module: "patientchart",
    fieldLabels: FIELD_LABELS_PATIENT_CHART_CACHE,
    fieldOrder: FIELD_ORDER_PATIENT_CHART_CACHE,
    defaultFields: FIELD_DEFAULTS_PATIENT_CHART_CACHE[role],
  });
}

/* ============================================================
   🔁 Sync Helper
============================================================ */
export function syncRefsToState() {
  // reserved for reactive integration / auto-binding
}
