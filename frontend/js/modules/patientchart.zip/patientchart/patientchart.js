// 📦 patientchart.js – Patient Chart Module Entry Point (Enterprise Aligned)

/* ============================================================
   ✅ Imports
============================================================ */

// 🧭 Main module init (handles list filters + table/card rendering)
import { initPatientChartModule } from "./patientchart-filter-main.js";

// 🧩 Core actions (view chart, summary, revalidate cache, delete)
import "./patientchart-actions.js";

// 🗒️ Notes lifecycle handlers (add/edit/delete/review/verify)
import "./patientchartnote-actions.js";

// 🧾 View log renderers (audit/compliance dashboard)
import "./patientchartlog-render.js";

// ⚙️ Constants (for dynamic columns or UI builders)
import {
  FIELD_LABELS_PATIENT_CHART_CACHE,
  FIELD_ORDER_PATIENT_CHART_CACHE,
  FIELD_DEFAULTS_PATIENT_CHART_CACHE,
  FIELD_LABELS_PATIENT_CHART_NOTE,
  FIELD_ORDER_PATIENT_CHART_NOTE,
  FIELD_DEFAULTS_PATIENT_CHART_NOTE,
  FIELD_LABELS_PATIENT_CHART_VIEW_LOG,
  FIELD_ORDER_PATIENT_CHART_VIEW_LOG,
  FIELD_DEFAULTS_PATIENT_CHART_VIEW_LOG,
} from "./patientchart-constants.js";

// 🛠 Utilities
import { showToast, hideLoading } from "../../utils/index.js";

/* ============================================================
   🚀 DOM-Ready Bootstrap
============================================================ */

document.addEventListener("DOMContentLoaded", async () => {
  try {
    // ✅ Initialize Patient Chart list/filter if its container exists
    if (document.getElementById("patientChartTableBody")) {
      await initPatientChartModule();
    }

    // 🗒️ Optionally detect notes page
    if (document.getElementById("patientChartNoteTableBody")) {
      console.info("🗒️ Patient Chart Notes page detected – handlers ready.");
    }

    // 🧾 Optionally detect logs dashboard
    if (document.getElementById("patientChartLogTableBody")) {
      console.info("🧾 Patient Chart Log page detected – compliance dashboard active.");
    }

  } catch (err) {
    console.error("❌ Failed to initialize patient chart module", err);
    hideLoading();
    showToast("❌ Failed to load patient chart module");
  }
});
