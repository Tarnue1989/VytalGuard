// 📦 status-action-matrix.js – Enterprise Master Pattern Aligned (Full + Compact)
// ============================================================================
// 🧠 STATUS → ACTION MATRIX + BUTTON BUILDER (Unified Enterprise Standard)
// ----------------------------------------------------------------------------
// 🔹 Covers all modules: Clinical, Billing, Inventory, Master Data, Admin, etc.
// 🔹 Standardized lifecycle actions (toggle-status, void, restore, delete, etc.)
// 🔹 Context-aware button labels (Deposit / Discount / Waiver)
// ============================================================================

export const STATUS_ACTION_MATRIX = {
  /* ======================== 🩺 CLINICAL ======================== */
  consultation:{open:["edit","start","cancel","void"],in_progress:["complete","cancel","void"],completed:["verify","void"],verified:["void"],cancelled:["void"],voided:["restore"]},
  triage_record:{open:["edit","start","cancel","void"],in_progress:["complete","cancel","void"],completed:["verify","void"],verified:["void"],cancelled:["void"],voided:["restore"]},
  ekg_record:{pending:["edit","start","cancel","void"],in_progress:["complete","cancel","void"],completed:["review","finalize","void"],reviewed:["finalize","void"],finalized:["verify","void"],verified:["void"],cancelled:["void"],voided:["restore"]},
  delivery_record:{scheduled:["edit","start","cancel","void"],in_progress:["complete","cancel","void"],completed:["verify","void"],verified:["void"],cancelled:["void"],voided:["restore"]},

  /* ======================== 📅 APPOINTMENT ======================== */
  appointment:{scheduled:["edit","activate","cancel","no-show","void"],in_progress:["complete","cancel","void"],completed:["verify","void"],verified:[],cancelled:["restore"],no_show:["restore"],voided:["restore"],deleted:["restore"]},

  /* ======================== 💰 DEPOSIT ======================== */
  deposit:{pending:["edit","clear","cancel","void","delete"],cleared:["apply","void","reverse"],applied:["apply","reverse","verify","void","print"],verified:["print"],cancelled:["restore"],reversed:["restore"],voided:["restore"],deleted:["restore"]},

  /* ======================== 💳 PAYMENT ======================== */
  payment:{pending:["edit","complete","cancel","void","delete"],completed:["verify","void","print"],verified:["print"],cancelled:["restore"],reversed:["restore"],voided:["restore"],deleted:["restore"]},

  /* ======================== 💸 DISCOUNT ======================== */
  discount:{draft:["edit","toggle-status","delete","void"],active:["toggle-status","finalize","void"],inactive:["toggle-status","void"],finalized:["void","restore","print"],voided:["restore"],deleted:["restore"]},

  /* ======================== 💸 DISCOUNT WAIVER ======================== */
  discount_waiver:{
    pending:["edit","approve","reject","void","delete"],
    approved:["finalize","void","print"],
    applied:["void","print"],
    rejected:["restore"],
    voided:["restore"],
    finalized:["print","void","restore"],
    deleted:["restore"],
  },
  /* ======================== 💵 REFUND ======================== */
  refund: {
    pending: ["edit", "approve", "reject", "cancel", "void", "delete"],
    approved: ["process", "cancel", "void"],
    processed: ["reverse", "void", "print"],
    reversed: ["restore"],
    rejected: ["restore"],
    cancelled: ["restore"],
    voided: ["restore"],
    deleted: ["restore"],
  },

  /* ======================== 🩹 SURGERY ======================== */
  surgery:{scheduled:["edit","start","cancel","void"],in_progress:["complete","cancel","void"],completed:["verify","void"],verified:["void"],cancelled:["void"],voided:["restore"]},

  /* ======================== 🩻 ULTRASOUND ======================== */
  ultrasound_record:{pending:["edit","start","cancel","void"],in_progress:["complete","cancel","void"],completed:["review","finalize","void"],reviewed:["finalize","void"],finalized:["verify","void"],verified:["void"],cancelled:["void"],voided:["restore"]},

  /* ======================== 🧪 LAB ======================== */
  lab_request:{draft:["edit","submit","delete","void"],pending:["edit","cancel","void"],approved:["process","void"],processed:["verify","void"],verified:["void"],cancelled:["void"],voided:["restore"]},
  lab_result:{draft:["edit","submit","delete","void"],pending:["edit","start","cancel","void"],in_progress:["complete","cancel","void"],completed:["review","void"],reviewed:["verify","void"],verified:[],cancelled:["void"],voided:["restore"]},

  /* ======================== 🩸 VITAL ======================== */
  vital:{open:["edit","start","cancel","void"],in_progress:["complete","finalize","cancel","void"],completed:["verify","void"],verified:["void"],cancelled:["void"],voided:["restore"]},

  /* ======================== 🧠 MEDICAL RECORD ======================== */
  medical_record:{draft:["edit","review","delete","void"],reviewed:["finalize","void"],finalized:["verify","void"],verified:["void"],voided:["restore"]},

  /* ======================== 💊 PRESCRIPTION ======================== */
  prescription:{draft:["edit","submit","delete","void"],issued:["edit","activate","cancel","void"],dispensed:["complete","verify","void"],completed:["verify","void"],verified:["void"],cancelled:["void"],voided:["restore"]},
  
  /* ======================== 💊 PHARMACY TRANSACTION ======================== */
  pharmacy_transaction:{
    pending:["edit","dispense","cancel","void","delete"],
    dispensed:["verify","print","void"],
    partially_dispensed:["dispense","verify","print","void"],
    returned:["verify","print"],
    verified:["print"],
    cancelled:["restore"],
    voided:["restore"],
    deleted:["restore"]
  },
  /* ======================== 🩺 PATIENT CHART ======================== */
  patient_charts: {
    active: ["summary", "revalidate", "print", "void"],
    stale: ["summary", "revalidate", "print", "void"],
    invalid: ["summary", "revalidate", "print", "restore"],
    voided: ["restore"]
  },

  /* ======================== 🩺 PATIENT CHART CACHE ======================== */
  patient_chart_cache: {
    active: ["summary", "revalidate", "print", "void"],
    stale: ["summary", "revalidate", "print", "void"],
    invalid: ["summary", "revalidate", "print", "restore"],
    voided: ["restore"],
    deleted: ["restore"]
  },

  /* ======================== 🗒️ PATIENT CHART NOTES ======================== */
  patient_chart_notes: {
    draft: ["view", "edit", "review", "verify", "delete", "void"],
    reviewed: ["view", "edit", "verify", "void"],
    verified: ["view", "void"],
    voided: ["restore"]
  },

  /* ======================== 👁️ PATIENT CHART VIEW LOGS ======================== */
  patient_chart_view_logs: {
    logged: ["view"],
    reviewed: ["view", "verify"],
    verified: ["view"],
    voided: ["restore"]
  },


  /* ======================== 🧾 REGISTRATION ======================== */
  registration_log:{draft:["edit","submit","delete","void"],pending:["edit","activate","cancel","void"],active:["complete","cancel","void"],completed:["verify","void"],verified:["void"],cancelled:["void"],voided:["restore"]},

  /* ======================== 💰 BILLING ======================== */
  billable_item:{active:["edit","toggle","delete","history"],inactive:["edit","toggle","delete","history"],deleted:["restore","history"]},
  auto_billing_rule:{active:["edit","toggle","delete","history"],inactive:["edit","toggle","delete","history"],deleted:["restore","history"]},

  /* ======================== 🏭 INVENTORY ======================== */
  central_stock:{active:["edit","toggle","lock","delete"],inactive:["edit","toggle","lock","delete"],locked:["unlock"],deleted:["restore"]},
  stock_request:{draft:["edit","submit","delete","void"],pending:["edit","approve","reject","cancel","void"],approved:["issue","cancel","void"],issued:["fulfill","void"],fulfilled:["verify","void"],cancelled:["void"],voided:["restore"]},

  /* ======================== 🧩 MASTER DATA ======================== */
  master_item:{active:["edit","toggle","delete"],inactive:["edit","toggle","delete"],deleted:["restore"]},
  master_item_category:{active:["edit","toggle","delete"],inactive:["edit","toggle","delete"],deleted:["restore"]},

  /* ======================== 👨‍💼 EMPLOYEE ======================== */
  employee:{active:["edit","toggle","delete"],inactive:["edit","toggle","delete"],terminated:["edit","toggle","delete"],deleted:["restore"]},

  /* ======================== 🏥 FACILITY ======================== */
  facility:{active:["edit","toggle","delete"],inactive:["edit","toggle","delete"],deleted:["restore"]},

  /* ======================== 🏢 ORGANIZATION ======================== */
  organization:{active:["edit","toggle","delete"],inactive:["edit","toggle","delete"],deleted:["restore"]},

  /* ======================== 🧍 PATIENT ======================== */
  patient:{active:["edit","toggle","delete"],inactive:["edit","toggle","delete"],cancelled:["edit","toggle","delete"],voided:["restore"],deleted:["restore"]},

  /* ======================== 🛡️ ADMIN ======================== */
  role:{active:["edit","toggle","delete"],inactive:["edit","toggle","delete"],deleted:["restore"]},
  permission:{active:["edit"]},
  department:{active:["edit","toggle","delete"],inactive:["edit","toggle","delete"],deleted:["restore"]},
};

/* ============================================================
   🧱 BUTTON BUILDER HELPERS (Enterprise Compact)
============================================================ */
function buildButton(action, title, icon, color, id) {
  return `<button class="btn btn-outline-${color} btn-sm ${action}-btn"
    type="button" data-id="${id}" data-action="${action}"
    data-bs-toggle="tooltip" data-bs-title="${title}" aria-label="${title}">
    <i class="fas ${icon}" aria-hidden="true"></i></button>`;
}

export function buildActionButtons({ module, status, entry, entryId, user, permissionPrefix }) {
  const isSuperAdmin =
    (user?.role && user.role.toLowerCase().includes("superadmin")) ||
    (user?.roleNames || []).some(r => r.toLowerCase().includes("superadmin"));
  const perms = new Set((user?.permissions || []).map(p => p.toLowerCase().trim()));
  let allowed = STATUS_ACTION_MATRIX[module]?.[status] || [];

  // 💰 Deposit rule adjustments
  if (module === "deposit") {
    const remaining = parseFloat(entry?.remaining_balance || 0);
    if (["cleared", "applied"].includes(status) && remaining <= 0) allowed = allowed.filter(a => a !== "apply");
    if (remaining > 0) allowed = allowed.filter(a => a !== "verify");
  }

  // 💵 Refund rules
  if (module === "refund" && ["reversed", "cancelled", "rejected", "voided"].includes(status))
    allowed = allowed.filter(a => a !== "process" && a !== "approve");

  const ORDER = [
    "view", "edit", "start", "complete", "review", "verify", "finalize", "apply",
    "process", "reverse", "clear", "revert", "approve", "reject", "cancel", "void",
    "toggle-status", "restore", "delete", "print"
  ];
  allowed.sort((a, b) =>
    (ORDER.indexOf(a) === -1 ? 999 : ORDER.indexOf(a)) -
    (ORDER.indexOf(b) === -1 ? 999 : ORDER.indexOf(b))
  );

  let html = "";
  if (perms.has(`${permissionPrefix}:view`) || isSuperAdmin)
    html += buildButton("view", "View", "fa-eye", "primary", entryId);

  const isDeposit = module === "deposit",
        isDiscountWaiver = module === "discount_waiver" || module === "discount-waiver",
        isDiscount = module === "discount",
        isRefund = module === "refund",
        isPharmacyTx = module === "pharmacy_transaction";

  for (const act of allowed) {
    const backend = act === "complete" ? "finalize" :
                    act === "clear" || act === "revert" ? "toggle-status" : act;
    const perm = `${permissionPrefix}:${backend}`;
    if (perms.has(perm) || isSuperAdmin) {
      const icons = {
        view:"fa-eye", edit:"fa-pen", start:"fa-play", complete:"fa-check", review:"fa-search",
        verify:"fa-clipboard-check", finalize:"fa-flag-checkered", apply:"fa-link", process:"fa-gears",
        reverse:"fa-rotate-left", clear:"fa-check-double", revert:"fa-undo-alt", approve:"fa-thumbs-up",
        reject:"fa-thumbs-down", cancel:"fa-ban", void:"fa-times-circle", restore:"fa-undo",
        delete:"fa-trash", print:"fa-print", "toggle-status":"fa-toggle-on",
        generate:"fa-database", revalidate:"fa-sync", summary:"fa-file-medical"
      },
      colors = {
        view:"primary", edit:"success", start:"primary", complete:"success", review:"warning",
        verify:"info", finalize:"dark", apply:"primary", process:"info", reverse:"warning",
        clear:"success", revert:"secondary", approve:"success", reject:"danger", cancel:"warning",
        void:"danger", restore:"primary", delete:"danger", print:"info", "toggle-status":"secondary",
        generate:"primary", revalidate:"info", summary:"success"
      },
      titles = {
        ...actionLabels,
        clear: isDeposit?"Clear Deposit":"Clear Record",
        revert:"Revert to Pending",
        apply: isDeposit?"Apply Deposit":isDiscountWaiver?"Apply Waiver":isDiscount?"Apply Discount":isRefund?"Apply Refund":isPharmacyTx?"Apply Pharmacy Tx":"Apply",
        process: isRefund?"Process Refund":isDiscountWaiver?"Process Waiver":isPharmacyTx?"Process Pharmacy Tx":"Process Record",
        reverse: isDeposit?"Reverse Deposit":isDiscountWaiver?"Reverse Waiver":isDiscount?"Reverse Discount":isRefund?"Reverse Refund":isPharmacyTx?"Reverse Pharmacy Tx":"Reverse",
        verify: isDeposit?"Verify Deposit":isDiscountWaiver?"Verify Waiver":isDiscount?"Verify Discount":isRefund?"Verify Refund":isPharmacyTx?"Verify Pharmacy Tx":"Verify",
        print: isDeposit?"Print Deposit Receipt":isDiscountWaiver?"Print Waiver":isDiscount?"Print Discount":isRefund?"Print Refund Receipt":isPharmacyTx?"Print Pharmacy Tx Receipt":"Print Record",
        approve:isRefund?"Approve Refund":"Approve",
        reject:isRefund?"Reject Refund":"Reject",
        cancel:isRefund?"Cancel Refund":"Cancel",
        "toggle-status":"Toggle Status",
        generate:"Generate Chart Cache", revalidate:"Revalidate Chart Cache", summary:"View Summary"
      };
      html += buildButton(act, titles[act]||act, icons[act]||"fa-cog", colors[act]||"secondary", entryId);
    }
  }
  return `<div class="d-inline-flex gap-1">${html}</div>`;
}

const actionLabels = {
  view:"View", edit:"Edit", start:"Start", complete:"Complete", review:"Review",
  verify:"Verify", finalize:"Finalize", apply:"Apply", process:"Process", reverse:"Reverse",
  clear:"Clear", revert:"Revert", approve:"Approve", reject:"Reject", cancel:"Cancel",
  void:"Void", restore:"Restore", delete:"Delete", print:"Print", "toggle-status":"Toggle Status"
};
