// 📁 backend/src/controllers/patientController.js
import Joi from "joi";
import fs from "fs";
import path from "path";
import { Op } from "sequelize";
import { sequelize, Patient, Facility, User, Organization, Employee } from "../models/index.js";
import { success, error } from "../utils/response.js";
import { buildQueryOptions } from "../utils/queryHelper.js";
import {
  GENDER_TYPES,
  DOB_PRECISION,
  MARITAL_STATUS,
  RELIGIONS,
  REGISTRATION_LOG_STATUS,
  REGISTRATION_METHODS,
} from "../constants/enums.js";
import { authzService } from "../services/authzService.js";
import { auditService } from "../services/auditService.js";
import { FIELD_VISIBILITY_PATIENT } from "../constants/fieldVisibility.js";
import { generatePatientQR } from "../services/qrService.js";

/* ============================================================
   🔧 HELPER
   ============================================================ */
function isSuperAdmin(user) {
  if (!user) return false;
  const roles = Array.isArray(user.roleNames) ? user.roleNames : [user.role || ""];
  return roles.map(r => r.toLowerCase()).includes("superadmin");
}
// Helper to generate unique patient number per org
async function generateNextPatientNo(orgId) {
  // get organization code for readability
  const org = await Organization.findByPk(orgId, { attributes: ["code"] });
  const prefix = org?.code ? `PAT-${org.code}-` : "PAT-";

  // find latest patient in this org
  const latest = await Patient.findOne({
    where: { organization_id: orgId },
    order: [["created_at", "DESC"]],
    attributes: ["pat_no"],
    paranoid: false,
  });

  let nextSeq = 1;
  if (latest?.pat_no) {
    const match = latest.pat_no.match(/(\d+)$/);
    if (match) nextSeq = parseInt(match[1], 10) + 1;
  }

  return `${prefix}${String(nextSeq).padStart(4, "0")}`;
}

/* ============================================================
   🔗 SHARED INCLUDES
   ============================================================ */
const PATIENT_INCLUDES = [
  { model: Organization, as: "organization", attributes: ["id", "name", "code"] },
  { model: Facility, as: "facility", attributes: ["id", "name", "code", "organization_id"] },
  { model: Employee, as: "registeredBy", attributes: ["id", "first_name", "last_name", "employee_no"] },
  { model: User, as: "createdBy", attributes: ["id", "first_name", "last_name"] },
  { model: User, as: "updatedBy", attributes: ["id", "first_name", "last_name"] },
  { model: User, as: "deletedBy", attributes: ["id", "first_name", "last_name"] },
];

/* ============================================================
   📋 ROLE-AWARE JOI SCHEMA (Enterprise Aligned – Patient Profile Only)
   ============================================================ */
function buildPatientSchema(mode = "create") {
  const base = {
    pat_no: Joi.string().max(50).allow("", null),
    first_name: Joi.string().max(120).required(),
    middle_name: Joi.string().max(120).allow("", null),
    last_name: Joi.string().max(120).required(),
    date_of_birth: Joi.date().allow("", null),
    date_of_birth_precision: Joi.string().valid(...DOB_PRECISION).allow("", null),
    gender: Joi.string().valid(...GENDER_TYPES).allow("", null),
    phone_number: Joi.string().allow("", null),

    // ✅ allow empty/null emails; true validation handled in Sequelize model
    email_address: Joi.string().email().allow("", null),
    home_address: Joi.string().allow("", null),

    marital_status: Joi.string().valid(...MARITAL_STATUS).allow("", null),
    religion: Joi.string().valid(...RELIGIONS).allow("", null),
    profession: Joi.string().max(120).allow("", null),

    national_id: Joi.string().max(50).allow("", null),
    insurance_number: Joi.string().max(50).allow("", null),
    passport_number: Joi.string().max(50).allow("", null),

    emergency_contact_name: Joi.string().allow("", null),
    emergency_contact_phone: Joi.string().allow("", null),

    // 🧾 Patient-only notes (no registration enums here)
    notes: Joi.string().allow("", null),

    employee_id: Joi.string().uuid().allow("", null),

    remove_photo: Joi.alternatives()
      .try(Joi.boolean(), Joi.string().valid("true", "false"))
      .optional(),

    remove_qr_code: Joi.alternatives()
      .try(Joi.boolean(), Joi.string().valid("true", "false"))
      .optional(),

    organization_id: Joi.string().uuid().allow(null),
    facility_id: Joi.string().uuid().allow(null),
  };

  if (mode === "update") {
    Object.keys(base).forEach((k) => (base[k] = base[k].optional()));
  }

  return Joi.object(base);
}

/* ============================================================
   📌 CREATE PATIENT (Enterprise-Aligned)
   ============================================================ */
export const createPatient = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "patient",
      action: "create",
      res,
    });
    if (!allowed) return;

    const schema = buildPatientSchema("create");
    const { error: validationError, value } = schema.validate(req.body, {
      stripUnknown: true,
    });
    if (validationError) {
      await t.rollback();
      return error(res, "Validation failed", validationError, 400);
    }

    // 🔹 Normalize email/phone for Sequelize validation safety
    if (typeof value.email_address === "string") {
      value.email_address = value.email_address.trim();
      if (value.email_address === "") value.email_address = null;
    }
    if (typeof value.phone_number === "string") {
      value.phone_number = value.phone_number.trim();
      if (value.phone_number === "") value.phone_number = null;
    }

    // 🏢 Org/facility resolution by role
    let orgId, facilityId;
    if (isSuperAdmin(req.user)) {
      orgId = value.organization_id;
      facilityId = value.facility_id;
      if (!orgId || !facilityId) {
        await t.rollback();
        return error(
          res,
          "Organization and Facility are required for superadmin",
          null,
          400
        );
      }
    } else {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id || null;
    }

    // 🔑 Auto-generate patient number if not provided
    if (!value.pat_no || value.pat_no.trim() === "") {
      value.pat_no = await generateNextPatientNo(orgId);
    }

    // 🚨 Duplicate checks
    const dupNo = await Patient.findOne({
      where: { organization_id: orgId, pat_no: value.pat_no },
      paranoid: false,
    });
    if (dupNo) {
      await t.rollback();
      return error(res, "Patient number already exists", null, 400);
    }

    if (value.phone_number) {
      const dupPhone = await Patient.findOne({
        where: { organization_id: orgId, phone_number: value.phone_number },
        paranoid: false,
      });
      if (dupPhone) {
        await t.rollback();
        return error(res, "Phone already exists", null, 400);
      }
    }

    if (value.email_address) {
      const dupEmail = await Patient.findOne({
        where: {
          organization_id: orgId,
          email_address: value.email_address.toLowerCase().trim(),
        },
        paranoid: false,
      });
      if (dupEmail) {
        await t.rollback();
        return error(res, "Email already exists", null, 400);
      }
    }

    // ✅ File uploads
    if (req.files?.photo_path?.[0]) {
      value.photo_path = `/uploads/patients/${req.files.photo_path[0].filename}`;
    }

    if (value.email_address)
      value.email_address = value.email_address.toLowerCase().trim();
    if (
      value.date_of_birth &&
      isNaN(new Date(value.date_of_birth).getTime())
    )
      value.date_of_birth = null;

    if (value.emergency_contact_name || value.emergency_contact_phone) {
      value.emergency_contacts = [
        {
          name: value.emergency_contact_name || "",
          phone: value.emergency_contact_phone || "",
        },
      ];
    }

    // 🧠 System-assigned default (not user editable)
    value.source_of_registration = "walk_in";

    const created = await Patient.create(
      {
        ...value,
        organization_id: orgId,
        facility_id: facilityId,
        created_by_id: req.user?.id || null,
      },
      { transaction: t }
    );

    // ✅ Generate QR
    const qrPath = await generatePatientQR(created.id, created.pat_no);
    await created.update({ qr_code_path: qrPath }, { transaction: t });

    await t.commit();

    const full = await Patient.findOne({
      where: { id: created.id },
      include: PATIENT_INCLUDES,
    });

    await auditService.logAction({
      user: req.user,
      module: "patient",
      action: "create",
      entityId: created.id,
      entity: created,
      details: value,
    });

    return success(res, "✅ Patient created", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to create patient", err);
  }
};

/* ============================================================
   📌 UPDATE PATIENT (Enterprise-Aligned)
   ============================================================ */
export const updatePatient = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "patient",
      action: "update",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const schema = buildPatientSchema("update");
    const { error: validationError, value } = schema.validate(req.body, {
      stripUnknown: true,
    });
    if (validationError) {
      await t.rollback();
      return error(res, "Validation failed", validationError, 400);
    }

    // 🔹 Normalize email/phone
    if (typeof value.email_address === "string") {
      value.email_address = value.email_address.trim();
      if (value.email_address === "") value.email_address = null;
    }
    if (typeof value.phone_number === "string") {
      value.phone_number = value.phone_number.trim();
      if (value.phone_number === "") value.phone_number = null;
    }

    const where = { id };
    if (!isSuperAdmin(req.user))
      where.organization_id = req.user.organization_id;

    const patient = await Patient.findOne({ where, transaction: t });
    if (!patient) {
      await t.rollback();
      return error(res, "Patient not found", null, 404);
    }

    // 🏢 Org/facility enforcement
    let orgId, facilityId;
    if (isSuperAdmin(req.user)) {
      orgId = value.organization_id || patient.organization_id;
      facilityId = value.facility_id || patient.facility_id;
    } else {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id || patient.facility_id;
      value.organization_id = orgId;
      value.facility_id = facilityId;
    }

    // 🚨 Duplicate checks
    if (value.pat_no && value.pat_no !== patient.pat_no) {
      const exists = await Patient.findOne({
        where: {
          organization_id: orgId,
          pat_no: value.pat_no,
          id: { [Op.ne]: id },
        },
        paranoid: false,
      });
      if (exists) {
        await t.rollback();
        return error(res, "Patient number already in use", null, 400);
      }
    }

    if (value.phone_number) {
      const dupPhone = await Patient.findOne({
        where: {
          organization_id: orgId,
          phone_number: value.phone_number,
          id: { [Op.ne]: id },
        },
        paranoid: false,
      });
      if (dupPhone) {
        await t.rollback();
        return error(res, "Phone number already in use", null, 400);
      }
    }

    if (value.email_address) {
      const dupEmail = await Patient.findOne({
        where: {
          organization_id: orgId,
          email_address: value.email_address,
          id: { [Op.ne]: id },
        },
        paranoid: false,
      });
      if (dupEmail) {
        await t.rollback();
        return error(res, "Email already in use", null, 400);
      }
    }

    // ✅ Handle remove flags
    ["remove_photo", "remove_qr_code"].forEach((flag) => {
      if (value[flag] === "true") value[flag] = true;
      if (value[flag] === "false") value[flag] = false;
    });

    if (value.remove_photo && patient.photo_path) {
      try {
        fs.unlinkSync(path.join(process.cwd(), patient.photo_path));
      } catch {}
      value.photo_path = null;
    }

    if (value.remove_qr_code && patient.qr_code_path) {
      try {
        fs.unlinkSync(path.join(process.cwd(), patient.qr_code_path));
      } catch {}
      value.qr_code_path = null;
    }

    // ✅ Handle uploads
    if (req.files?.photo_path?.[0]) {
      value.photo_path = `/uploads/patients/${req.files.photo_path[0].filename}`;
    }

    if (
      value.date_of_birth &&
      isNaN(new Date(value.date_of_birth).getTime())
    ) {
      value.date_of_birth = null;
    }

    if (value.emergency_contact_name || value.emergency_contact_phone) {
      value.emergency_contacts = [
        {
          name: value.emergency_contact_name || "",
          phone: value.emergency_contact_phone || "",
        },
      ];
    }

    // 🧠 Preserve system-managed fields (never overridden by form)
    delete value.source_of_registration;
    delete value.registration_status;

    await patient.update(
      {
        ...value,
        organization_id: orgId,
        facility_id: facilityId,
        updated_by_id: req.user?.id || null,
      },
      { transaction: t }
    );

    // 🔄 Regenerate QR if needed
    if (
      !patient.qr_code_path ||
      (value.pat_no && value.pat_no !== patient.pat_no)
    ) {
      const qrPath = await generatePatientQR(
        patient.id,
        value.pat_no || patient.pat_no
      );
      await patient.update({ qr_code_path: qrPath }, { transaction: t });
    }

    await t.commit();

    const full = await Patient.findOne({
      where: { id },
      include: PATIENT_INCLUDES,
    });

    await auditService.logAction({
      user: req.user,
      module: "patient",
      action: "update",
      entityId: id,
      entity: full,
      details: value,
    });

    return success(res, "✅ Patient updated", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to update patient", err);
  }
};

/* ============================================================
   📌 TOGGLE PATIENT STATUS
   ============================================================ */
export const togglePatientStatus = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "patient",
      action: "update",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") {
        where.facility_id = req.user.facility_id;
      }
    }

    const patient = await Patient.findOne({ where });
    if (!patient) return error(res, "Patient not found", null, 404);

    // use registration_status enum
    const [DRAFT, PENDING, ACTIVE, COMPLETED, CANCELLED, VOIDED] = REGISTRATION_LOG_STATUS;
    const newStatus = patient.registration_status === ACTIVE ? CANCELLED : ACTIVE;

    await patient.update({ registration_status: newStatus, updated_by_id: req.user?.id || null });

    const full = await Patient.findOne({ where: { id }, include: PATIENT_INCLUDES });

    await auditService.logAction({
      user: req.user,
      module: "patient",
      action: "toggle_status",
      entityId: id,
      entity: full,
      details: { from: patient.registration_status, to: newStatus },
    });

    return success(res, `Patient status set to ${newStatus}`, full);
  } catch (err) {
    return error(res, "Failed to toggle patient status", err);
  }
};

/* ============================================================
   📌 GET ALL PATIENTS (Enterprise-Aligned)
   ============================================================ */
export const getAllPatients = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "patient",
      action: "read",
      res,
    });
    if (!allowed) return;

    const role = (req.user?.roleNames?.[0] || "staff").toLowerCase();
    const visibleFields =
      FIELD_VISIBILITY_PATIENT[role] || FIELD_VISIBILITY_PATIENT.staff;

    const options = buildQueryOptions(req, "last_name", "ASC", visibleFields);

    // 🏢 Org/facility scoping
    if (!isSuperAdmin(req.user)) {
      options.where = {
        ...(options.where || {}),
        organization_id: req.user.organization_id,
      };
      if (role === "facility_head") {
        options.where.facility_id = req.user.facility_id;
      }
    }

    // 🔍 Global filter (specific ID)
    if (req.query.global) {
      options.where = {
        ...(options.where || {}),
        id: req.query.global,
      };
    }

    // 🔍 Text search
    if (options.search && !req.query.global) {
      options.where[Op.or] = [
        { first_name: { [Op.iLike]: `%${options.search}%` } },
        { last_name: { [Op.iLike]: `%${options.search}%` } },
        { middle_name: { [Op.iLike]: `%${options.search}%` } },
        { pat_no: { [Op.iLike]: `%${options.search}%` } },
        { phone_number: { [Op.iLike]: `%${options.search}%` } },
        { email_address: { [Op.iLike]: `%${options.search}%` } },
      ];
    }

    const { count, rows } = await Patient.findAndCountAll({
      where: options.where,
      attributes: options.attributes
        ? [...new Set(["id", ...options.attributes])]
        : undefined,
      include: [...PATIENT_INCLUDES, ...(options.include || [])],
      order: options.order?.length ? options.order : [["last_name", "ASC"]],
      offset: options.offset,
      limit: options.limit,
    });

    await auditService.logAction({
      user: req.user,
      module: "patient",
      action: "list",
      details: { query: req.query, returned: count },
    });

    return success(res, "✅ Patients loaded", {
      records: rows,
      pagination: {
        total: count,
        page: options.pagination.page,
        pageCount: Math.ceil(count / options.pagination.limit),
      },
    });
  } catch (err) {
    return error(res, "❌ Failed to load patients", err);
  }
};

/* ============================================================
   📌 GET PATIENT BY ID
   ============================================================ */
export const getPatientById = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "patient",
      action: "read",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") {
        where.facility_id = req.user.facility_id;
      }
    }

    const patient = await Patient.findOne({ where, include: PATIENT_INCLUDES });
    if (!patient) return error(res, "❌ Patient not found", null, 404);

    await auditService.logAction({
      user: req.user,
      module: "patient",
      action: "view",
      entityId: id,
      entity: patient,
    });

    return success(res, "✅ Patient loaded", patient);
  } catch (err) {
    return error(res, "❌ Failed to load patient", err);
  }
};

/* ============================================================
   📌 GET ALL PATIENTS LITE WITH CONTACT
   ============================================================ */
export const getAllPatientsLiteWithContact = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "patient",
      action: "read",
      res,
    });
    if (!allowed) return;

    const { q } = req.query;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { deleted_at: null };

    // 🏢 Tenant scope
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") where.facility_id = req.user.facility_id;
    }

    // 🔍 Smart search
    if (q) {
      where[Op.or] = [
        { first_name: { [Op.iLike]: `%${q}%` } },
        { middle_name: { [Op.iLike]: `%${q}%` } },
        { last_name: { [Op.iLike]: `%${q}%` } },
        { pat_no: { [Op.iLike]: `%${q}%` } },
        { phone_number: { [Op.iLike]: `%${q}%` } },
        { email_address: { [Op.iLike]: `%${q}%` } },
      ];
    }

    const patients = await Patient.findAll({
      where,
      attributes: [
        "id",
        "pat_no",
        "first_name",
        "middle_name",
        "last_name",
        "phone_number",
        "email_address",
      ],
      order: [
        [
          sequelize.fn(
            "concat_ws",
            " ",
            sequelize.col("first_name"),
            sequelize.col("middle_name"),
            sequelize.col("last_name")
          ),
          "ASC",
        ],
      ],
      limit: 20,
    });

    const result = patients.map((p) => ({
      id: p.id,
      pat_no: p.pat_no,
      full_name: [p.first_name, p.middle_name, p.last_name]
        .filter(Boolean)
        .join(" ")
        .replace(/\s+/g, " ")
        .trim(),
      phone: p.phone_number || "",
      email: p.email_address || "",
    }));

    await auditService.logAction({
      user: req.user,
      module: "patient",
      action: "list_lite_contact",
      details: { count: result.length, query: q || null },
    });

    return success(res, "✅ Patients loaded (lite + contact)", {
      records: result,
    });
  } catch (err) {
    return error(res, "❌ Failed to load patients (lite + contact)", err);
  }
};

/* ============================================================
   📌 GET ALL PATIENTS LITE (ID + NAME)
   ============================================================ */
export const getAllPatientsLite = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "patient",
      action: "read",
      res,
    });
    if (!allowed) return;

    const { q } = req.query;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { deleted_at: null };

    // 🏢 Tenant scope
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") where.facility_id = req.user.facility_id;
    }

    // 🔍 Smart name/ID search
    if (q) {
      where[Op.or] = [
        { first_name: { [Op.iLike]: `%${q}%` } },
        { middle_name: { [Op.iLike]: `%${q}%` } },
        { last_name: { [Op.iLike]: `%${q}%` } },
        { pat_no: { [Op.iLike]: `%${q}%` } },
      ];
    }

    const patients = await Patient.findAll({
      where,
      attributes: ["id", "pat_no", "first_name", "middle_name", "last_name"],
      order: [
        [
          sequelize.fn(
            "concat_ws",
            " ",
            sequelize.col("first_name"),
            sequelize.col("middle_name"),
            sequelize.col("last_name")
          ),
          "ASC",
        ],
      ],
      limit: 20,
    });

    const result = patients.map((p) => {
      const fullName = [p.first_name, p.middle_name, p.last_name]
        .filter(Boolean)
        .join(" ")
        .replace(/\s+/g, " ")
        .trim();
      return {
        id: p.id,
        pat_no: p.pat_no,
        full_name: fullName,
        label: p.pat_no ? `${fullName} (${p.pat_no})` : fullName,
      };
    });

    await auditService.logAction({
      user: req.user,
      module: "patient",
      action: "list_lite",
      details: { query: q || null, count: result.length },
    });

    return success(res, "✅ Patients loaded (lite)", { records: result });
  } catch (err) {
    return error(res, "❌ Failed to load patients (lite)", err);
  }
};

/* ============================================================
   📌 DELETE PATIENT (Soft Delete)
   ============================================================ */
/* ============================================================
   📌 DELETE PATIENT (Soft Delete + File Cleanup)
   ============================================================ */
export const deletePatient = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "patient",
      action: "delete",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") {
        where.facility_id = req.user.facility_id;
      }
    }

    const patient = await Patient.findOne({ where, transaction: t });
    if (!patient) {
      await t.rollback();
      return error(res, "Patient not found", null, 404);
    }

    // 🚨 (Optional safeguard) block delete if patient has critical records
    // Example: Admissions or Invoices. Adjust based on business rules.
    // const hasAdmission = await Admission.count({ where: { patient_id: id }, transaction: t });
    // if (hasAdmission > 0) {
    //   await t.rollback();
    //   return error(res, "Cannot delete — patient has admissions linked", null, 400);
    // }

    // ✅ Cleanup uploaded files (photo + QR)
    try {
      if (patient.photo_path) {
        fs.unlinkSync(path.join(process.cwd(), patient.photo_path));
      }
      if (patient.qr_code_path) {
        fs.unlinkSync(path.join(process.cwd(), patient.qr_code_path));
      }
    } catch (fileErr) {
      // Don’t block deletion if file is already missing
      console.warn("⚠️ File cleanup error:", fileErr.message);
    }

    await patient.update({ deleted_by_id: req.user?.id || null }, { transaction: t });
    await patient.destroy({ transaction: t });

    await t.commit();

    const full = await Patient.findOne({
      where: { id },
      include: PATIENT_INCLUDES,
      paranoid: false, // ✅ include soft-deleted
    });

    await auditService.logAction({
      user: req.user,
      module: "patient",
      action: "delete",
      entityId: id,
      entity: full,
    });

    return success(res, "✅ Patient deleted (files cleaned up)", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to delete patient", err);
  }
};
