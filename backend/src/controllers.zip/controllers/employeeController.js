import Joi from "joi";
import fs from "fs";
import path from "path";
import { Op } from "sequelize";
import { sequelize, Employee, Facility, Department, User, Organization } from "../models/index.js";
import { success, error } from "../utils/response.js";
import { buildQueryOptions } from "../utils/queryHelper.js";
import { EMPLOYEE_STATUS, GENDER_TYPES, EMPLOYEE_POSITIONS } from "../constants/enums.js";
import { authzService } from "../services/authzService.js";
import { auditService } from "../services/auditService.js";
import { FIELD_VISIBILITY_EMPLOYEE } from "../constants/fieldVisibility.js";
import { FACILITY_REQUIRED_POSITIONS } from "../constants/employeeRules.js"; // 👈 new import

/* ============================================================
   🔧 HELPER
   ============================================================ */
function isSuperAdmin(user) {
  if (!user) return false;
  const roles = Array.isArray(user.roleNames) ? user.roleNames : [user.role || ""];
  return roles.map(r => r.toLowerCase()).includes("superadmin");
}

/* ============================================================
   🔗 SHARED INCLUDES
   ============================================================ */
const EMPLOYEE_INCLUDES = [
  { model: Organization, as: "organization", attributes: ["id", "name", "code"] },
  { model: Facility, as: "facility", attributes: ["id", "name", "code", "organization_id"] },
  { model: Department, as: "department", attributes: ["id", "name", "code"] },
  { model: User, as: "user", attributes: ["id", "first_name", "last_name", "email"] },
  { model: User, as: "createdBy", attributes: ["id", "first_name", "last_name"] },
  { model: User, as: "updatedBy", attributes: ["id", "first_name", "last_name"] },
  { model: User, as: "deletedBy", attributes: ["id", "first_name", "last_name"] },
];

/* ============================================================
   📋 ROLE-BASED JOI SCHEMA FACTORY
   ============================================================ */
function buildEmployeeSchema(userRole) {
  // Base schema (shared for all roles)
  const base = {
    first_name: Joi.string().max(80).required(),
    middle_name: Joi.string().max(80).allow("", null),
    last_name: Joi.string().max(80).required(),
    gender: Joi.string().valid(...GENDER_TYPES).required(),
    dob: Joi.date().allow("", null),
    phone: Joi.string().allow("", null),
    email: Joi.string().email().allow("", null),
    address: Joi.string().allow("", null),
    employee_no: Joi.string().max(50).required(),
    department_id: Joi.string().uuid().allow("", null),
    position: Joi.string().valid(...EMPLOYEE_POSITIONS).required(),
    status: Joi.string().valid(...EMPLOYEE_STATUS).default(EMPLOYEE_STATUS[0]),
    license_no: Joi.string().allow("", null),
    specialty: Joi.string().allow("", null),
    certifications: Joi.string().allow("", null),
    hire_date: Joi.date().allow("", null),
    termination_date: Joi.date().allow("", null),
    emergency_contact_name: Joi.string().allow("", null),
    emergency_contact_phone: Joi.string().allow("", null),
    user_id: Joi.string().uuid().allow("", null),

    // 🔧 file removal flags
    remove_photo: Joi.alternatives().try(Joi.boolean(), Joi.string().valid("true", "false")).optional(),
    remove_resume: Joi.alternatives().try(Joi.boolean(), Joi.string().valid("true", "false")).optional(),
    remove_document: Joi.alternatives().try(Joi.boolean(), Joi.string().valid("true", "false")).optional(),
  };

  // Default facility/org fields (optional unless overridden by role)
  base.organization_id = Joi.string().uuid().allow("", null);
  base.facility_id = Joi.string().uuid().allow("", null);

  // Apply role-specific overrides
  switch (userRole) {
    case "superadmin":
      // superadmin → can set both org + facility (no extra restriction)
      break;

    case "org_owner":
      // org is auto-assigned → forbid passing it
      base.organization_id = Joi.forbidden();
      // facility optional (can pick or null)
      break;

    case "admin":
      // org is auto-assigned
      base.organization_id = Joi.forbidden();
      // facility required for admins
      base.facility_id = Joi.string().uuid().required();
      break;

    case "facility_head":
      // both auto-assigned → forbid passing them
      base.organization_id = Joi.forbidden();
      base.facility_id = Joi.forbidden();
      break;

    default: // staff and others
      base.organization_id = Joi.forbidden();
      base.facility_id = Joi.forbidden(); // staff’s facility is auto or null
      break;
  }

  return Joi.object(base);
}


/* ============================================================
   📌 CREATE EMPLOYEE (reload full record before returning)
   ============================================================ */
export const createEmployee = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "employee",
      action: "create",
      res,
    });
    if (!allowed) return;

    const role = (req.user?.roleNames?.[0] || "").toLowerCase();
    const schema = buildEmployeeSchema(role);
    const { error: validationError, value } = schema.validate(req.body, { stripUnknown: true });
    if (validationError) {
      await t.rollback();
      return error(res, "Validation failed", validationError, 400);
    }

    // normalize UUIDs
    ["department_id", "facility_id", "organization_id", "user_id"].forEach(f => {
      if (!value[f] || value[f] === "") value[f] = null;
    });

    // Role-based assignment
    let orgId = req.user.organization_id || null;
    let facilityId = null;

    if (role === "superadmin") {
      orgId = value.organization_id || req.body.organization_id;
      facilityId = value.facility_id || req.body.facility_id || null;
    } else if (role === "org_owner") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id || null;
    } else if (role === "admin") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id; // required by Joi
    } else if (role === "facility_head") {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id; // auto from login
    } else {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id || null;
    }

    if (!orgId) {
      await t.rollback();
      return error(res, "Missing organization assignment", null, 400);
    }

    // 🚨 Enforce facility requirement by position
    if (
      value.position &&
      FACILITY_REQUIRED_POSITIONS.includes(value.position.toLowerCase()) &&
      !facilityId
    ) {
      await t.rollback();
      return error(res, `Position "${value.position}" requires a facility assignment`, null, 400);
    }

    // check duplicates
    const exists = await Employee.findOne({
      where: { organization_id: orgId, employee_no: value.employee_no },
      paranoid: false,
    });
    if (exists) {
      await t.rollback();
      return error(res, "Employee number already exists in this organization", null, 400);
    }

    // uploads
    if (req.files) {
      if (req.files.employee_photo?.[0]) value.photo_path = `/uploads/employees/${req.files.employee_photo[0].filename}`;
      if (req.files.resume_url?.[0]) value.resume_url = `/uploads/resumes/${req.files.resume_url[0].filename}`;
      if (req.files.document_url?.[0]) value.document_url = `/uploads/documents/${req.files.document_url[0].filename}`;
    }

    if (value.email) value.email = value.email.toLowerCase().trim();
    ["dob", "hire_date", "termination_date"].forEach(f => {
      if (!value[f] || isNaN(new Date(value[f]).getTime())) value[f] = null;
    });
    value.full_name = [value.first_name, value.middle_name, value.last_name].filter(Boolean).join(" ").trim();

    const created = await Employee.create(
      { ...value, organization_id: orgId, facility_id: facilityId, created_by_id: req.user?.id || null },
      { transaction: t }
    );
    await t.commit();

    const full = await Employee.findOne({ where: { id: created.id }, include: EMPLOYEE_INCLUDES });

    await auditService.logAction({
      user: req.user,
      module: "employee",
      action: "create",
      entityId: created.id,
      entity: created,
      details: value,
    });

    return success(res, "✅ Employee created", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to create employee", err);
  }
};


/* ============================================================
   📌 UPDATE EMPLOYEE (reload full record before returning)
   ============================================================ */
export const updateEmployee = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "employee",
      action: "update",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;

    const role = (req.user?.roleNames?.[0] || "").toLowerCase();
    const schema = buildEmployeeSchema(role);
    const { error: validationError, value } = schema.validate(req.body, { stripUnknown: true });
    if (validationError) {
      await t.rollback();
      return error(res, "Validation failed", validationError, 400);
    }

    ["remove_photo", "remove_resume", "remove_document"].forEach(flag => {
      if (value[flag] === "true") value[flag] = true;
      if (value[flag] === "false") value[flag] = false;
    });
    ["department_id", "facility_id", "organization_id", "user_id"].forEach(f => {
      if (!value[f] || value[f] === "") value[f] = null;
    });

    const where = { id };
    if (!isSuperAdmin(req.user)) where.organization_id = req.user.organization_id;

    const employee = await Employee.findOne({ where, transaction: t });
    if (!employee) {
      await t.rollback();
      return error(res, "Employee not found", null, 404);
    }

    // unique employee_no check
    const exists = await Employee.findOne({
      where: {
        organization_id: req.user.organization_id,
        employee_no: value.employee_no,
        id: { [Op.ne]: id },
      },
      paranoid: false,
    });
    if (exists) {
      await t.rollback();
      return error(res, "Employee number already in use in this organization", null, 400);
    }

    // 🔑 Role-based assignment
    let orgId = req.user.organization_id || null;
    let facilityId = null;

    if (role === "superadmin") {
      orgId = value.organization_id || req.body.organization_id;
      facilityId = value.facility_id || req.body.facility_id || null;
    } else if (role === "org_owner") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id || null;
    } else if (role === "admin") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id;
    } else if (role === "facility_head") {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id;
    } else {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id || null;
    }

    // 🚨 Enforce facility requirement by position
    if (
      value.position &&
      FACILITY_REQUIRED_POSITIONS.includes(value.position.toLowerCase()) &&
      !facilityId
    ) {
      await t.rollback();
      return error(res, `Position "${value.position}" requires a facility assignment`, null, 400);
    }

    if (value.remove_photo) value.photo_path = null;
    if (value.remove_resume) value.resume_url = null;
    if (value.remove_document) value.document_url = null;

    if (req.files) {
      if (req.files.employee_photo?.[0]) value.photo_path = `/uploads/employees/${req.files.employee_photo[0].filename}`;
      if (req.files.resume_url?.[0]) value.resume_url = `/uploads/resumes/${req.files.resume_url[0].filename}`;
      if (req.files.document_url?.[0]) value.document_url = `/uploads/documents/${req.files.document_url[0].filename}`;
    }

    if (value.email) value.email = value.email.toLowerCase().trim();
    ["dob", "hire_date", "termination_date"].forEach(f => {
      if (!value[f] || isNaN(new Date(value[f]).getTime())) value[f] = null;
    });
    value.full_name = [value.first_name, value.middle_name, value.last_name]
      .filter(Boolean)
      .join(" ")
      .trim();

    await employee.update(
      { ...value, organization_id: orgId, facility_id: facilityId, updated_by_id: req.user?.id || null },
      { transaction: t }
    );

    await t.commit();

    const full = await Employee.findOne({ where: { id }, include: EMPLOYEE_INCLUDES });

    await auditService.logAction({
      user: req.user,
      module: "employee",
      action: "update",
      entityId: id,
      entity: full,
      details: value,
    });

    return success(res, "✅ Employee updated", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to update employee", err);
  }
};


/* ============================================================
   📌 DELETE EMPLOYEE (Soft Delete)
   ============================================================ */
export const deleteEmployee = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "employee",
      action: "delete",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") {
        where.facility_id = req.user.facility_id; // 🔒 restrict deletion scope
      }
    }

    const employee = await Employee.findOne({ where, transaction: t });
    if (!employee) {
      await t.rollback();
      return error(res, "Employee not found", null, 404);
    }

    if (employee.user_id) {
      const hasUser = await User.count({ where: { id: employee.user_id }, transaction: t });
      if (hasUser > 0) {
        await t.rollback();
        return error(res, "Cannot delete — employee is linked to a user account", null, 400);
      }
    }

    await employee.update({ deleted_by_id: req.user?.id || null }, { transaction: t });
    await employee.destroy({ transaction: t });

    await t.commit();

    const full = await Employee.findOne({
      where: { id },
      include: EMPLOYEE_INCLUDES,
      paranoid: false,
    });

    await auditService.logAction({
      user: req.user,
      module: "employee",
      action: "delete",
      entityId: id,
      entity: full, // 👈 capture org/facility from soft-deleted record
    });

    return success(res, "Employee deleted successfully", full);
  } catch (err) {
    await t.rollback();
    return error(res, "Failed to delete employee", err);
  }
};

/* ============================================================
   📌 TOGGLE EMPLOYEE STATUS
   ============================================================ */
export const toggleEmployeeStatus = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "employee",
      action: "update",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") {
        where.facility_id = req.user.facility_id; // 🔒 restrict to their facility
      }
    }

    const employee = await Employee.findOne({ where });
    if (!employee) return error(res, "Employee not found", null, 404);

    const [ACTIVE, INACTIVE] = EMPLOYEE_STATUS;
    const newStatus = employee.status === ACTIVE ? INACTIVE : ACTIVE;

    await employee.update({ status: newStatus, updated_by_id: req.user?.id || null });

    // 🔥 reload full record with associations
    const full = await Employee.findOne({ where: { id }, include: EMPLOYEE_INCLUDES });

    await auditService.logAction({
      user: req.user,
      module: "employee",
      action: "toggle_status",
      entityId: id,
      entity: full, // 👈 now capturing the full employee record
      details: { from: employee.status, to: newStatus },
    });

    return success(res, `Employee status set to ${newStatus}`, full);
  } catch (err) {
    return error(res, "Failed to toggle employee status", err);
  }
};

/* ============================================================
   📌 GET ALL EMPLOYEES
   ============================================================ */
export const getAllEmployees = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "employee",
      action: "read",
      res,
    });
    if (!allowed) return;

    const role = (req.user?.roleNames?.[0] || "staff").toLowerCase();
    const visibleFields =
      FIELD_VISIBILITY_EMPLOYEE[role] || FIELD_VISIBILITY_EMPLOYEE.staff;

    const options = buildQueryOptions(req, "last_name", "ASC", visibleFields);

    // 🔒 Scope
    if (!isSuperAdmin(req.user)) {
      options.where = {
        ...(options.where || {}),
        organization_id: req.user.organization_id,
      };
      if (role === "facility_head") {
        options.where.facility_id = req.user.facility_id;
      }
    }

    // ✅ Handle global (UUID from autocomplete)
    if (req.query.global) {
      options.where = {
        ...(options.where || {}),
        id: req.query.global,   // direct match on employee.id
      };
    }

    // 🔎 Search support
    if (options.search && !req.query.global) {
      options.where[Op.or] = [
        { first_name: { [Op.iLike]: `%${options.search}%` } },
        { last_name: { [Op.iLike]: `%${options.search}%` } },
        { employee_no: { [Op.iLike]: `%${options.search}%` } },
      ];
    }

    const { count, rows } = await Employee.findAndCountAll({
      where: options.where,
      attributes: options.attributes
        ? [...new Set(["id", ...options.attributes])]
        : undefined,
      include: [...EMPLOYEE_INCLUDES, ...(options.include || [])],
      order: options.order?.length ? options.order : [["last_name", "ASC"]],
      offset: options.offset,
      limit: options.limit,
    });

    await auditService.logAction({
      user: req.user,
      module: "employee",
      action: "list",
      details: { query: req.query, returned: count },
    });

    return success(res, "✅ Employees loaded", {
      records: rows,
      pagination: {
        total: count,
        page: options.pagination.page,
        pageCount: Math.ceil(count / options.pagination.limit),
      },
    });
  } catch (err) {
    return error(res, "❌ Failed to load employees", err);
  }
};

/* ============================================================
   📌 GET EMPLOYEE BY ID (full record)
   ============================================================ */
export const getEmployeeById = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "employee",
      action: "read",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") {
        where.facility_id = req.user.facility_id; // 🔒 restrict
      }
    }

    const employee = await Employee.findOne({
      where,
      include: EMPLOYEE_INCLUDES,
    });

    if (!employee) return error(res, "❌ Employee not found", null, 404);

    await auditService.logAction({
      user: req.user,
      module: "employee",
      action: "view",
      entityId: id,
      entity: employee, // ✅ log entity so org/facility are captured
    });

    return success(res, "✅ Employee loaded", employee);
  } catch (err) {
    return error(res, "❌ Failed to load employee", err);
  }
};

/* ============================================================
   📌 GET ALL EMPLOYEES LITE WITH EMAIL (with ?q= and ?position support)
   ============================================================ */
export const getAllEmployeesLiteWithEmail = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "employee",
      action: "read",
      res,
    });
    if (!allowed) return;

    const { q, position } = req.query;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { deleted_at: null, status: "active" };

    // 🔒 Scope enforcement
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") {
        where.facility_id = req.user.facility_id;
      }
    }

    // 🔎 Apply search filter
    if (q) {
      where[Op.or] = [
        { first_name: { [Op.iLike]: `%${q}%` } },
        { middle_name: { [Op.iLike]: `%${q}%` } },
        { last_name: { [Op.iLike]: `%${q}%` } },
        { email: { [Op.iLike]: `%${q}%` } },
        { employee_no: { [Op.iLike]: `%${q}%` } },
      ];
    }

    // 🔎 Optional filter by position
    if (position) {
      where.position = position;
    }

    const employees = await Employee.findAll({
      where,
      attributes: [
        "id",
        "employee_no",
        "first_name",
        "middle_name",
        "last_name",
        "email",
      ],
      order: [[
        sequelize.fn("concat_ws", " ",
          sequelize.col("first_name"),
          sequelize.col("middle_name"),
          sequelize.col("last_name")),
        "ASC"
      ]],
      limit: 20, // 👈 autocomplete friendly
    });

    const result = employees.map(emp => ({
      id: emp.id,
      employee_no: emp.employee_no,
      full_name: [emp.first_name, emp.middle_name, emp.last_name]
        .filter(Boolean)
        .join(" ")
        .replace(/\s+/g, " ")
        .trim(),
      email: emp.email || "",
    }));

    await auditService.logAction({
      user: req.user,
      module: "employee",
      action: "list_lite_email",
      details: { count: result.length, query: q || null, position: position || null },
    });

    return success(res, "✅ Employees loaded (lite + email)", { records: result });
  } catch (err) {
    return error(res, "❌ Failed to load employees (lite + email)", err);
  }
};


/* ============================================================
   📌 GET ALL EMPLOYEES LITE (with ?q and ?position support)
   ============================================================ */
export const getAllEmployeesLite = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "employee",
      action: "read",
      res,
    });
    if (!allowed) return;

    const { q, position } = req.query;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { deleted_at: null, status: "active" };

    // 🔒 Scope enforcement
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") {
        where.facility_id = req.user.facility_id;
      }
    }

    // 🔎 Apply search filter
    if (q) {
      where[Op.or] = [
        { first_name: { [Op.iLike]: `%${q}%` } },
        { middle_name: { [Op.iLike]: `%${q}%` } },
        { last_name: { [Op.iLike]: `%${q}%` } },
        { employee_no: { [Op.iLike]: `%${q}%` } },
      ];
    }

    // 🔎 Optional filter by position
    if (position) {
      where.position = position;
    }

    const employees = await Employee.findAll({
      where,
      attributes: ["id", "employee_no", "first_name", "middle_name", "last_name"],
      order: [[
        sequelize.fn("concat_ws", " ",
          sequelize.col("first_name"),
          sequelize.col("middle_name"),
          sequelize.col("last_name")),
        "ASC"
      ]],
      limit: 20, // ✅ autocomplete-friendly
    });

    const result = employees.map(emp => {
      const fullName = [emp.first_name, emp.middle_name, emp.last_name]
        .filter(Boolean)
        .join(" ")
        .replace(/\s+/g, " ")
        .trim();

      return {
        id: emp.id,
        employee_no: emp.employee_no,
        full_name: fullName,
        label: emp.employee_no 
          ? `${fullName} (${emp.employee_no})`
          : fullName, // ✅ nice display for suggestions
      };
    });

    await auditService.logAction({
      user: req.user,
      module: "employee",
      action: "list_lite",
      details: { query: q || null, position: position || null, count: result.length },
    });

    return success(res, "✅ Employees loaded (lite)", { records: result });
  } catch (err) {
    return error(res, "❌ Failed to load employees (lite)", err);
  }
};