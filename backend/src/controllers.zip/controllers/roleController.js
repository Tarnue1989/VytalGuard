// 📁 controllers/roleController.js
import Joi from "joi";
import { Op } from "sequelize";
import { sequelize, Role, User, Facility, Organization } from "../models/index.js";
import { success, error } from "../utils/response.js";
import { buildQueryOptions } from "../utils/queryHelper.js";
import { ROLE_STATUS } from "../constants/enums.js";
import { authzService } from "../services/authzService.js";
import { auditService } from "../services/auditService.js";
import { isSuperAdmin, isOrgOwner, isFacilityHead, hasRole } from "../utils/role-utils.js";

const MODULE_KEY = "roles";

/* ============================================================
   🔗 SHARED INCLUDES
   ============================================================ */
const ROLE_INCLUDES = [
  { model: Organization, as: "organization", attributes: ["id", "name", "code"] },
  { model: Facility, as: "facility", attributes: ["id", "name", "code", "organization_id"] },
  { model: User, as: "createdBy", attributes: ["id", "first_name", "last_name"] },
  { model: User, as: "updatedBy", attributes: ["id", "first_name", "last_name"] },
  { model: User, as: "deletedBy", attributes: ["id", "first_name", "last_name"] },
];

/* ============================================================
   📋 ROLE-BASED JOI SCHEMA (simplified — backend injects org/fac)
   ============================================================ */
function buildRoleSchema(userRole, mode = "create") {
  const base = {
    name: Joi.string().max(80).required(),
    code: Joi.string().max(50).allow("", null),
    description: Joi.string().allow("", null),
    is_system: Joi.boolean().default(false),
    requires_facility: Joi.boolean().default(false),
  };

  if (mode === "update") {
    base.status = Joi.string().valid(...ROLE_STATUS).optional();
    Object.keys(base).forEach((k) => (base[k] = base[k].optional()));
  }

  // 🔑 Superadmins can explicitly include org/fac
  if (userRole === "superadmin") {
    base.organization_id = Joi.string().uuid().optional();
    base.facility_id = Joi.string().uuid().optional();
  }

  // All other roles → backend injects org/facility
  return Joi.object(base);
}

/* ============================================================
   📌 CREATE ROLE
   ============================================================ */
export const createRole = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: MODULE_KEY,
      action: "create",
      res,
    });
    if (!allowed) return;

    const role = (req.user?.roleNames?.[0] || "").toLowerCase();
    const schema = buildRoleSchema(role, "create");
    const { error: validationError, value } = schema.validate(req.body, { stripUnknown: true });

    if (validationError) {
      await t.rollback();
      return error(res, "Validation failed", validationError, 400);
    }

    // 🧭 Scope resolution
    let orgId = req.user.organization_id || null;
    let facilityId = null;
    if (role === "superadmin") {
      orgId = value.organization_id || req.body.organization_id || null;
      facilityId = value.facility_id || req.body.facility_id || null;
    } else if (role === "org_owner") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id || null;
    } else if (role === "admin") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id;
    } else if (role === "facility_head") {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id;
    } else {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id || null;
    }

    if (!orgId) {
      await t.rollback();
      return error(res, "Missing organization assignment", null, 400);
    }

    // 🚫 Uniqueness check
    const exists = await Role.findOne({
      where: { organization_id: orgId, facility_id: facilityId, name: value.name },
      paranoid: false,
    });
    if (exists) {
      await t.rollback();
      return error(res, "Role with this name already exists in this scope", null, 400);
    }

    const created = await Role.create(
      {
        ...value,
        organization_id: orgId,
        facility_id: facilityId,
        role_type: value.is_system ? "system" : "custom",
        created_by_id: req.user?.id || null,
      },
      { transaction: t }
    );

    await t.commit();

    const full = await Role.findOne({ where: { id: created.id }, include: ROLE_INCLUDES });

    await auditService.logAction({
      user: req.user,
      module: MODULE_KEY,
      action: "create",
      entityId: created.id,
      entity: full,
      details: value,
    });

    return success(res, "✅ Role created", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to create role", err);
  }
};

/* ============================================================
   📌 UPDATE ROLE
   ============================================================ */
export const updateRole = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: MODULE_KEY,
      action: "update",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();
    const schema = buildRoleSchema(role, "update");
    const { error: validationError, value } = schema.validate(req.body, { stripUnknown: true });

    if (validationError) {
      await t.rollback();
      return error(res, "Validation failed", validationError, 400);
    }

    // 🧭 Scope resolution
    let orgId = req.user.organization_id || null;
    let facilityId = null;
    if (isSuperAdmin(req.user)) {
      orgId = value.organization_id || req.query.organization_id || null;
      facilityId = value.facility_id || req.query.facility_id || null;
    } else if (isOrgOwner(req.user)) {
      orgId = req.user.organization_id;
      facilityId = value.facility_id || null;
    } else if (role === "admin") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id;
    } else if (role === "facility_head") {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id;
    } else {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id || null;
    }

    if (!orgId) {
      await t.rollback();
      return error(res, "Missing organization assignment", null, 400);
    }

    const record = await Role.findOne({ where: { id, organization_id: orgId }, transaction: t });
    if (!record) {
      await t.rollback();
      return error(res, "❌ Role not found", null, 404);
    }

    if (record.role_type === "system" && !isSuperAdmin(req.user)) {
      await t.rollback();
      return error(res, "❌ Cannot update a system role", null, 403);
    }

    if (value.name) {
      const exists = await Role.findOne({
        where: {
          organization_id: orgId,
          facility_id: facilityId,
          name: value.name,
          id: { [Op.ne]: id },
        },
        paranoid: false,
      });
      if (exists) {
        await t.rollback();
        return error(res, "Role with this name already exists in this scope", null, 400);
      }
    }

    await record.update(
      {
        ...value,
        organization_id: orgId,
        facility_id: facilityId,
        updated_by_id: req.user?.id || null,
        ...(value.is_system !== undefined
          ? { role_type: value.is_system ? "system" : "custom" }
          : {}),
      },
      { transaction: t }
    );

    await t.commit();

    const full = await Role.findOne({ where: { id }, include: ROLE_INCLUDES });

    await auditService.logAction({
      user: req.user,
      module: MODULE_KEY,
      action: "update",
      entityId: id,
      entity: full,
      details: value,
    });

    return success(res, "✅ Role updated", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to update role", err);
  }
};

/* ============================================================
   📌 GET ALL ROLES
   ============================================================ */
export const getAllRoles = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "role",
      action: "read",
      res,
    });
    if (!allowed) return;

    const role = (req.user?.roleNames?.[0] || "staff").toLowerCase().replace(/\s+/g, "");
    const options = buildQueryOptions(req, "name", "ASC");

    options.where = options.where || {};

    if (!isSuperAdmin(req.user)) {
      options.where.organization_id = req.user.organization_id;
      if (role === "facilityhead") {
        options.where.facility_id = req.user.facility_id;
      }
      options.where.role_type = { [Op.ne]: "system" }; // block system roles
    } else {
      if (req.query.organization_id) options.where.organization_id = req.query.organization_id;
      if (req.query.facility_id) options.where.facility_id = req.query.facility_id;
    }

    if (options.search) {
      options.where[Op.or] = [
        { name: { [Op.iLike]: `%${options.search}%` } },
        { code: { [Op.iLike]: `%${options.search}%` } },
        { description: { [Op.iLike]: `%${options.search}%` } },
      ];
    }

    const { count, rows } = await Role.findAndCountAll({
      where: options.where,
      include: ROLE_INCLUDES,
      order: options.order,
      offset: options.offset,
      limit: options.limit,
    });

    await auditService.logAction({
      user: req.user,
      module: "role",
      action: "list",
      details: { query: req.query, returned: count },
    });

    return success(res, "✅ Roles loaded", {
      records: rows,
      pagination: {
        total: count,
        page: options.pagination.page,
        pageCount: Math.ceil(count / options.pagination.limit),
      },
    });
  } catch (err) {
    return error(res, "❌ Failed to load roles", err);
  }
};

/* ============================================================
   📌 GET ROLE BY ID
   ============================================================ */
export const getRoleById = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "role",
      action: "read",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "staff").toLowerCase().replace(/\s+/g, "");

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facilityhead") {
        where.facility_id = req.user.facility_id;
      }
      where.role_type = { [Op.ne]: "system" };
    } else {
      if (req.query.organization_id) where.organization_id = req.query.organization_id;
      if (req.query.facility_id) where.facility_id = req.query.facility_id;
    }

    const found = await Role.findOne({ where, include: ROLE_INCLUDES });
    if (!found) return error(res, "❌ Role not found", null, 404);

    await auditService.logAction({
      user: req.user,
      module: "role",
      action: "view",
      entityId: id,
      entity: found,
    });

    return success(res, "✅ Role loaded", found);
  } catch (err) {
    return error(res, "❌ Failed to load role", err);
  }
};

/* ============================================================
   📌 GET ROLES LITE (with ?q= support for autocomplete)
   ============================================================ */
export const getAllRolesLite = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "role",
      action: "read",
      res,
    });
    if (!allowed) return;

    const role = (req.user?.roleNames?.[0] || "staff")
      .toLowerCase()
      .replace(/\s+/g, "");
    const { q } = req.query;

    const where = { status: ROLE_STATUS[0] };

    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facilityhead") where.facility_id = req.user.facility_id;
      where.role_type = { [Op.ne]: "system" };
    } else {
      if (req.query.organization_id) where.organization_id = req.query.organization_id;
      if (req.query.facility_id) where.facility_id = req.query.facility_id;
    }

    // 🔎 Autocomplete search
    if (q) {
      where[Op.or] = [
        { name: { [Op.iLike]: `%${q}%` } },
        { code: { [Op.iLike]: `%${q}%` } },
        { description: { [Op.iLike]: `%${q}%` } },
      ];
    }

    const roles = await Role.findAll({
      where,
      attributes: ["id", "name", "code", "description", "role_type"],
      order: [["name", "ASC"]],
      limit: 20, // 👈 cap results for autocomplete
    });

    const result = roles.map(r => ({
      id: r.id,
      name: r.name,
      code: r.code || "",
      description: r.description || "",
      is_system: r.role_type === "system",
    }));

    await auditService.logAction({
      user: req.user,
      module: "role",
      action: "list_lite",
      details: { count: result.length, q },
    });

    // ✅ Unified shape with `{ records: [...] }`
    return success(res, "✅ Roles loaded (lite)", { records: result });
  } catch (err) {
    return error(res, "❌ Failed to load roles (lite)", err);
  }
};



/* ============================================================
   📌 TOGGLE ROLE STATUS
   ============================================================ */
export const toggleRoleStatus = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "role",
      action: "update",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const roleName = (req.user?.roleNames?.[0] || "").toLowerCase().replace(/\s+/g, "");

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (roleName === "facilityhead") where.facility_id = req.user.facility_id;
      where.role_type = { [Op.ne]: "system" };
    } else {
      if (req.query.organization_id) where.organization_id = req.query.organization_id;
      if (req.query.facility_id) where.facility_id = req.query.facility_id;
    }

    const role = await Role.findOne({ where });
    if (!role) return error(res, "❌ Role not found", null, 404);

    if (role.role_type === "system" && !isSuperAdmin(req.user)) {
      return error(res, "❌ Cannot toggle a system role", null, 403);
    }

    const [ACTIVE, INACTIVE] = ROLE_STATUS;
    const newStatus = role.status === ACTIVE ? INACTIVE : ACTIVE;

    await role.update({ status: newStatus, updated_by_id: req.user?.id || null });
    const full = await Role.findOne({ where: { id }, include: ROLE_INCLUDES });

    await auditService.logAction({
      user: req.user,
      module: "role",
      action: "toggle_status",
      entityId: id,
      entity: full,
      details: { from: role.status, to: newStatus },
    });

    return success(res, `✅ Role status set to ${newStatus}`, full);
  } catch (err) {
    return error(res, "❌ Failed to toggle role status", err);
  }
};

/* ============================================================
   📌 DELETE ROLE (Soft Delete with Audit)
   ============================================================ */
export const deleteRole = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "role",
      action: "delete",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const roleName = (req.user?.roleNames?.[0] || "").toLowerCase().replace(/\s+/g, "");

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (roleName === "facilityhead") where.facility_id = req.user.facility_id;
      where.role_type = { [Op.ne]: "system" };
    } else {
      if (req.query.organization_id) where.organization_id = req.query.organization_id;
      if (req.query.facility_id) where.facility_id = req.query.facility_id;
    }

    const role = await Role.findOne({ where, transaction: t });
    if (!role) {
      await t.rollback();
      return error(res, "❌ Role not found", null, 404);
    }

    if (role.role_type === "system" && !isSuperAdmin(req.user)) {
      await t.rollback();
      return error(res, "❌ Cannot delete a system role", null, 403);
    }

    await role.update({ deleted_by_id: req.user?.id || null }, { transaction: t });
    await role.destroy({ transaction: t });
    await t.commit();

    const full = await Role.findOne({ where: { id }, include: ROLE_INCLUDES, paranoid: false });

    await auditService.logAction({
      user: req.user,
      module: "role",
      action: "delete",
      entityId: id,
      entity: full,
    });

    return success(res, "✅ Role deleted", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to delete role", err);
  }
};
