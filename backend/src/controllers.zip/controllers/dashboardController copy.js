// 📁 controllers/dashboardController.js
import { Op } from "sequelize";
import { FeatureModule, FeatureAccess } from "../models/index.js";

/* -------------------- KPI HANDLERS (stubs or your real impls) -------------------- */
// Replace the bodies with your actual queries. They must resolve { count: number }.
async function getAppointmentsKpi(facilityIds) { return { count: 0 }; }
async function getLabRequestsKpi(facilityIds)  { return { count: 0 }; }
async function getAdmissionsKpi(facilityIds)   { return { count: 0 }; }
async function getPrescriptionsKpi(facilityIds){ return { count: 0 }; }

/* -------------------- KPI HANDLER MAP -------------------- */
const moduleKpiHandlers = {
  appointments:   getAppointmentsKpi,
  lab_requests:   getLabRequestsKpi,
  admissions:     getAdmissionsKpi,
  prescriptions:  getPrescriptionsKpi,
};

/* -------------------- Route resolver -------------------- */
/** explicit map for modules whose file name doesn’t match the key 1:1 */
const ROUTE_MAP = {
  departments:      "/department-list.html",
  facilities:       "/facilities-list.html",
  feature_access:   "/feature-access-list.html",
  feature_modules:  "/feature-module-list.html",
  organizations:    "/organization-list.html",
  roles:            "/role-list.html",
  users:            "/users-list.html",
};
/** prefer DB route, then explicit map, then a safe hyphenated fallback */
function resolveRoute(mod) {
  if (mod?.route) return mod.route;
  if (mod?.key && ROUTE_MAP[mod.key]) return ROUTE_MAP[mod.key];
  return `/${String(mod?.key || "").replace(/_/g, "-")}-list.html`;
}

/* -------------------- Helpers -------------------- */
// Convert Sequelize instances to plain JSON (so logs don’t show [Object])
function toPlain(rows) {
  if (!rows) return rows;
  if (Array.isArray(rows)) return rows.map(r => (typeof r?.get === "function" ? r.get({ plain: true }) : r));
  return typeof rows?.get === "function" ? rows.get({ plain: true }) : rows;
}

/* ==========================================================
   📌 MAIN CONTROLLER: GET DASHBOARD DATA
   ========================================================== */
export const getDashboardData = async (req, res) => {
  try {
    const { roles, facility_ids: facilityIds } = req.user;

    // ✅ Detect Super Admin (consistent with facility/employee controllers)
    const isSuperAdmin = Array.isArray(roles) && roles.some(
      r =>
        (r.name || "").toLowerCase() === "super admin" ||
        (r.normalized || "").toLowerCase() === "superadmin"
    ) || (req.user?.email || "").toLowerCase() === "superadmin@vytalguard.com";

    // 🚫 Guard: Non-super users must have facility context
    if (!isSuperAdmin && (!facilityIds || facilityIds.length === 0)) {
      return res.status(403).json({ error: "❌ Facility context not found" });
    }

    let modules;
    if (isSuperAdmin) {
      // 1️⃣ Super Admin: full access, no filtering
      modules = await FeatureModule.findAll({
        where: { enabled: true, status: "active", deleted_at: null },
        order: [["category", "ASC"], ["name", "ASC"]],
      });
    } else {
      // 2️⃣ Normal roles: filter by role + facility
      const roleIds = (roles || []).map(r => r.id).filter(Boolean);

      modules = await FeatureModule.findAll({
        include: [
          {
            model: FeatureAccess,
            as: "access",
            where: {
              role_id: { [Op.in]: roleIds }, // multi-role support
              [Op.or]: [
                { facility_id: { [Op.in]: facilityIds || [] } }, // multi-facility support
                { facility_id: null },
              ],
              status: "active",
            },
            attributes: [],
            required: true,
          },
        ],
        where: { enabled: true, status: "active", deleted_at: null },
        order: [["category", "ASC"], ["name", "ASC"]],
      });
    }

    // ➜ make them plain for logging/consumption
    modules = toPlain(modules);

    // 🔎 Debug: log which modules user got
    console.log("🧩 Modules for user:", req.user.id, JSON.stringify({
      roleNames: (roles || []).map(r => r.name),
      facilityIds,
      moduleKeys: (modules || []).map(m => m.key),
      routes: (modules || []).map(m => ({ key: m.key, route: m.route })),
    }, null, 2));

    // 3️⃣ Build KPIs dynamically
    const kpis = [];
    for (const m of modules) {
      if (moduleKpiHandlers[m.key]) {
        try {
          const result = await moduleKpiHandlers[m.key](facilityIds);
          kpis.push({
            label: m.name,
            count: Number(result?.count || 0),
            icon: m.icon,
            link: resolveRoute(m),
          });
        } catch (err) {
          console.warn(`⚠️ Skipping KPI for ${m.key} (handler error):`, err?.message || err);
        }
      }
    }

    // 4️⃣ Example Charts (stubbed)
    const charts = [
      {
        label: "Monthly Appointments",
        type: "bar",
        data: { labels: ["Jan", "Feb", "Mar"], series: [120, 150, 180] },
      },
    ];

    // 5️⃣ Example Queues (stubbed)
    const queues = [
      {
        label: "Pending Lab Requests",
        items: [
          { id: 1, patient: "John Doe", test: "CBC" },
          { id: 2, patient: "Jane Smith", test: "Lipid Profile" },
        ],
      },
    ];

    // 6️⃣ Example Alerts (stubbed)
    const alerts = [
      { type: "warning", message: "3 lab results awaiting verification" },
      { type: "danger", message: "Stock for Paracetamol below threshold" },
    ];

    const payload = { kpis, charts, queues, alerts };

    // 🔎 Debug full response
    console.log("📊 Dashboard response for user:", req.user.id, JSON.stringify(payload, null, 2));

    res.json(payload);
  } catch (err) {
    console.error("❌ Error loading dashboard:", err);
    res.status(500).json({ error: err.message });
  }
};
