// 📁 controllers/userController.js
import Joi from "joi";
import { Op } from "sequelize";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { 
  sequelize, 
  User, 
  Facility, 
  Role, 
  UserFacility, 
  PasswordHistory, 
  RefreshToken  
} from "../models/index.js";
import { success, error } from "../utils/response.js";
import { buildQueryOptions } from "../utils/queryHelper.js";
import { USER_STATUS } from "../constants/enums.js";
import crypto from "crypto"; // ensure this is at top of file

/* ============================================================
   📌 HELPER: Resolve Scope
   ============================================================ */
function resolveScope(req) {
  if (req.user?.roleNames?.includes("superadmin")) {
    return { scope: "superadmin", facility_id: null, organization_id: null };
  }
  if (req.user?.organization_id) {
    return {
      scope: "organization",
      organization_id: req.user.organization_id,
      facility_id: null,
    };
  }
  if (req.user?.facility_id) {
    return {
      scope: "facility",
      facility_id: req.user.facility_id,
      organization_id: null,
    };
  }
  return { scope: "none", facility_id: null, organization_id: null };
}

/* ============================================================
   📌 GET ALL USERS (Advanced filter + pagination + scoping)
   ============================================================ */
export const getAllUsers = async (req, res) => {
  try {
    const { scope, facility_id, organization_id } = resolveScope(req);

    // ✅ use new helper signature
    const options = buildQueryOptions(req, "username", "ASC", [
      "id",
      "username",
      "email",
      "first_name",
      "last_name",
      "status",
      "last_login_at",
      "locked_until",
      "organization_id",
      "created_at",
      "updated_at",
      "deleted_at",
    ]);

    options.where = options.where || {};

    // 🔎 Apply search (username/email/first/last)
    if (options.search) {
      const searchFilter = {
        [Op.or]: [
          { username: { [Op.iLike]: `%${options.search}%` } },
          { email: { [Op.iLike]: `%${options.search}%` } },
          { first_name: { [Op.iLike]: `%${options.search}%` } },
          { last_name: { [Op.iLike]: `%${options.search}%` } },
        ],
      };
      options.where = { [Op.and]: [options.where, searchFilter] };
    }

    // 📌 Facility include
    const facilityInclude = {
      model: Facility,
      as: "facilities",
      attributes: ["id", "name", "code", "organization_id"],
      through: { attributes: [] },
      required: false,
    };

    // 📌 Role include
    const roleInclude = {
      model: Role,
      as: "roles",
      attributes: ["id", "name", "requires_facility"],
      through: { attributes: [] },
      required: false,
    };

    // 🏥 facility filter
    if (req.query.facility_id) {
      facilityInclude.where = { id: req.query.facility_id };
      facilityInclude.required = true;
    }

    // 👤 role filter
    if (req.query.role_id) {
      roleInclude.where = { id: req.query.role_id };
      roleInclude.required = true;
    }

    // 📌 Scope enforcement
    if (scope === "facility") {
      facilityInclude.where = { ...(facilityInclude.where || {}), id: facility_id };
      facilityInclude.required = true;
    } else if (scope === "organization") {
      const orgFilter = {
        [Op.or]: [
          { organization_id },
          { "$facilities.organization_id$": organization_id },
        ],
      };
      options.where = { [Op.and]: [options.where, orgFilter] };
    }

    // 🔎 Run query
    const { count, rows } = await User.findAndCountAll({
      where: options.where,
      attributes: options.attributes,
      include: [
        facilityInclude,
        roleInclude,
        { model: User, as: "createdByUser", attributes: ["id", "first_name", "last_name", "username"] },
        { model: User, as: "updatedByUser", attributes: ["id", "first_name", "last_name", "username"] },
        { model: User, as: "deletedByUser", attributes: ["id", "first_name", "last_name", "username"] },
      ],
      order: options.order,
      offset: options.offset,
      limit: options.limit,
    });

    return success(res, "✅ Users loaded", {
      records: rows,
      pagination: {
        total: count,
        page: options.pagination.page,
        pageCount: Math.ceil(count / options.pagination.limit),
      },
    });
  } catch (err) {
    console.error("❌ getAllUsers error:", err);
    return error(res, "❌ Failed to load users", {}, 500);
  }
};

/* ============================================================
   📌 GET USER BY ID
   ============================================================ */
export const getUserById = async (req, res) => {
  try {
    const { scope, facility_id, organization_id } = resolveScope(req);
    const { id } = req.params;

    const options = buildQueryOptions(req, "username", "ASC", [
      "id",
      "username",
      "email",
      "first_name",
      "last_name",
      "status",
      "last_login_at",
      "locked_until",
      "organization_id",
      "created_at",
      "updated_at",
      "deleted_at",
    ]);

    const user = await User.findByPk(id, {
      attributes: options.attributes,
      include: [
        { model: Facility, as: "facilities", attributes: ["id", "name", "code", "organization_id"], through: { attributes: [] } },
        { model: Role, as: "roles", attributes: ["id", "name", "requires_facility"], through: { attributes: [] } },
        {
          model: User,
          as: "createdByUser",
          attributes: [
            "id", "username", "first_name", "last_name",
            [sequelize.literal(`COALESCE("createdByUser"."first_name" || ' ' || "createdByUser"."last_name", "createdByUser"."username")`), "full_name"],
          ],
        },
        {
          model: User,
          as: "updatedByUser",
          attributes: [
            "id", "username", "first_name", "last_name",
            [sequelize.literal(`COALESCE("updatedByUser"."first_name" || ' ' || "updatedByUser"."last_name", "updatedByUser"."username")`), "full_name"],
          ],
        },
        {
          model: User,
          as: "deletedByUser",
          attributes: [
            "id", "username", "first_name", "last_name",
            [sequelize.literal(`COALESCE("deletedByUser"."first_name" || ' ' || "deletedByUser"."last_name", "deletedByUser"."username")`), "full_name"],
          ],
        },
      ],
    });

    if (!user) return error(res, "❌ User not found", {}, 404);

    // 🔒 Scope enforcement
    if (scope === "facility") {
      const inFacility = user.facilities.some((f) => f.id === facility_id);
      if (!inFacility) return error(res, "❌ Not authorized", {}, 403);
    } else if (scope === "organization") {
      const inOrg = user.organization_id === organization_id ||
                    user.facilities.some((f) => f.organization_id === organization_id);
      if (!inOrg) return error(res, "❌ Not authorized", {}, 403);
    }

    return success(res, "✅ User loaded", user);
  } catch (err) {
    console.error("❌ getUserById error:", err);
    return error(res, "❌ Failed to load user", {}, 500);
  }
};


/* ============================================================
   📌 TOGGLE USER STATUS
   ============================================================ */
export const toggleUserStatus = async (req, res) => {
  try {
    const { id } = req.params;
    if (req.user.id === id) {
      return error(res, "❌ Cannot disable your own account", {}, 403);
    }

    console.log("🔎 [toggleUserStatus] Incoming toggle request for user ID:", id);

    const user = await User.findByPk(id, {
      paranoid: false,
      include: [
        {
          model: Facility,
          as: "facilities",
          attributes: ["id", "organization_id"],
          required: false,
        },
        {
          model: Role,
          as: "roles",
          attributes: ["id", "name"],
          through: { attributes: [] },
          required: false,
        },
      ],
    });

    if (!user) {
      console.warn(`⚠️ [toggleUserStatus] User not found for ID: ${id}`);
      return error(res, `❌ User not found for ID ${id}`, {}, 404);
    }

    // 🔒 Protect critical accounts
    if (user.is_system) {
      return error(res, "❌ Cannot change status of system accounts", {}, 403);
    }
    if (user.roles?.some((r) => r.name.toLowerCase().includes("superadmin"))) {
      return error(res, "❌ Cannot change status of superadmin accounts", {}, 403);
    }

    // Enforce scope
    const { scope, facility_id, organization_id } = resolveScope(req);
    if (scope === "facility") {
      const inFacility = user.facilities.some((f) => f.id === facility_id);
      if (!inFacility) return error(res, "❌ Not authorized", {}, 403);
    } else if (scope === "organization") {
      const inOrg =
        user.organization_id === organization_id ||
        user.facilities.some((f) => f.organization_id === organization_id);
      if (!inOrg) return error(res, "❌ Not authorized", {}, 403);
    }

    // Toggle
    user.status = user.status === "active" ? "inactive" : "active";
    user.updated_by_id = req.user.id;
    await user.save();

    // ✅ Return id + status so frontend can patch row directly
      return success(
        res,
        `✅ User ${user.status}`,
        { id: user.id, status: user.status }
      );
  } catch (err) {
    console.error("❌ toggleUserStatus error:", err);
    return error(res, "❌ Failed to toggle status", {}, 500);
  }
};


/* ============================================================
   📌 CREATE USER (with UserFacility + PasswordHistory)
   ============================================================ */
export const createUser = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { scope, facility_id, organization_id } = resolveScope(req);

    const schema = Joi.object({
      username: Joi.string().max(80).required(),
      email: Joi.string().email().max(150).required(),
      password: Joi.string().min(6).required(),
      first_name: Joi.string().max(150).allow("", null),
      last_name: Joi.string().max(150).allow("", null),
      status: Joi.string().valid(...USER_STATUS).default("active"),
      assignments: Joi.array().items(
        Joi.object({
          facility_id: Joi.string().uuid().required(),
          role_id: Joi.string().uuid().required(),
        })
      ).default([]),
      organization_id: Joi.string().uuid().optional(), // only for superadmin
    });

    const { error: validationError, value } = schema.validate(req.body);
    if (validationError) {
      return error(res, validationError.details[0].message, {}, 400);
    }

    // Unique username/email
    const exists = await User.findOne({
      where: { [Op.or]: [{ username: value.username }, { email: value.email }] },
      paranoid: false,
    });
    if (exists) {
      return error(res, "❌ Username or email already exists", {}, 409);
    }

    // Scope enforcement
    if (scope === "facility") {
      value.assignments = value.assignments
        .filter((a) => a.facility_id === facility_id)
        .map((a) => ({ ...a, facility_id }));

      if (!value.assignments.length) {
        return error(res, "❌ Cannot assign outside your facility", {}, 403);
      }

      const fac = await Facility.findByPk(facility_id);
      value.organization_id = fac?.organization_id || null;
    } else if (scope === "organization") {
      const facilities = await Facility.findAll({
        where: { id: value.assignments.map((a) => a.facility_id) },
      });
      const invalid = facilities.some(
        (f) => f.organization_id !== organization_id
      );
      if (invalid) {
        return error(res, "❌ Cannot assign outside your organization", {}, 403);
      }
      value.organization_id = organization_id;
    } else if (scope === "superadmin") {
      value.organization_id = value.organization_id || null;
    }

    // 🔒 Check requires_facility
    const roleIds = value.assignments.map((a) => a.role_id);
    if (roleIds.length > 0) {
      const roles = await Role.findAll({ where: { id: roleIds } });
      const mustHaveFacility = roles.some((r) => r.requires_facility === true);

      if (mustHaveFacility && value.assignments.length === 0) {
        return error(
          res,
          "❌ One or more roles require facility assignment",
          {},
          400
        );
      }
    }

    // ✅ Hash password, remove plain password
    const password_hash = await bcrypt.hash(value.password, 10);
    delete value.password;

    const created = await User.create(
      {
        ...value,
        password_hash,
        created_by_id: req.user?.id || null,
      },
      { transaction: t }
    );

    // 📌 Store initial password into password_history
    await PasswordHistory.create(
      { user_id: created.id, password_hash },
      { transaction: t }
    );

    // Create UserFacility assignments
    await Promise.all(
      value.assignments.map((a) =>
        UserFacility.create(
          {
            user_id: created.id,
            facility_id: a.facility_id,
            role_id: a.role_id,
            created_by_id: req.user?.id || null,
          },
          { transaction: t }
        )
      )
    );

    await t.commit();

    const fresh = await User.findByPk(created.id, {
      attributes: [
        "id",
        "username",
        "email",
        "first_name",
        "last_name",
        "status",
        "last_login_at",
        "organization_id",
      ],
      include: [
        {
          model: Facility,
          as: "facilities",
          attributes: ["id", "name", "code", "organization_id"],
          through: { attributes: [] },
        },
        {
          model: Role,
          as: "roles",
          attributes: ["id", "name", "requires_facility"],
          through: { attributes: [] },
        },
      ],
    });

    return success(res, "✅ User created", fresh);
  } catch (err) {
    console.error("❌ createUser error:", err);
    return error(res, "❌ Failed to create user", {}, 500);
  } finally {
    if (!t.finished) await t.rollback();
  }
};

/* ============================================================
   📌 UPDATE USER (with PasswordHistory check)
   ============================================================ */
export const updateUser = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { scope, facility_id, organization_id } = resolveScope(req);
    const { id } = req.params;

    console.log("🔎 [updateUser] Incoming update request for user ID:", id);

    const schema = Joi.object({
      username: Joi.string().max(80).optional(),
      email: Joi.string().email().max(150).optional(),
      password: Joi.string().min(6).allow("", null).optional(),
      first_name: Joi.string().max(150).allow("", null).optional(),
      last_name: Joi.string().max(150).allow("", null).optional(),
      status: Joi.string().valid(...USER_STATUS).optional(),
      assignments: Joi.array().items(
        Joi.object({
          facility_id: Joi.string().uuid().required(),
          role_id: Joi.string().uuid().required(),
        })
      ).optional(),
      organization_id: Joi.string().uuid().optional(),
    });

    const { error: validationError, value } = schema.validate(req.body);
    if (validationError) {
      return error(res, validationError.details[0].message, {}, 400);
    }

    // 🔎 Lookup user
    let user = await User.findByPk(id, {
      paranoid: false,
      include: [
        {
          model: Facility,
          as: "facilities",
          attributes: ["id", "organization_id"],
          required: false,
        },
        {
          model: Role,
          as: "roles",
          attributes: ["id", "name", "requires_facility"],
          through: { attributes: [] },
          required: false,
        },
      ],
    });

    if (!user) {
      return error(res, `❌ User not found for ID ${id}`, {}, 404);
    }

    // Scope checks
    if (scope === "facility") {
      const inFacility = user.facilities.some((f) => f.id === facility_id);
      if (!inFacility) {
        return error(res, "❌ Not authorized to update this user", {}, 403);
      }
      const fac = await Facility.findByPk(facility_id);
      value.organization_id = fac?.organization_id || null;
    } else if (scope === "organization") {
      const inOrg =
        user.organization_id === organization_id ||
        user.facilities.some((f) => f.organization_id === organization_id);
      if (!inOrg) {
        return error(res, "❌ Not authorized to update this user", {}, 403);
      }
      value.organization_id = organization_id;
    } else if (scope !== "superadmin") {
      delete value.organization_id;
    }

    // 🔒 Protect system/superadmin accounts
    if (user.is_system) {
      return error(res, "❌ Cannot update system accounts", {}, 403);
    }
    if (user.roles?.some((r) => r.name.toLowerCase().includes("superadmin"))) {
      return error(res, "❌ Cannot update superadmin accounts", {}, 403);
    }

    // Uniqueness check
    if (value.username || value.email) {
      const exists = await User.findOne({
        where: {
          [Op.or]: [
            ...(value.username ? [{ username: value.username }] : []),
            ...(value.email ? [{ email: value.email }] : []),
          ],
          id: { [Op.ne]: id },
        },
        paranoid: false,
      });
      if (exists) {
        return error(res, "❌ Username or email already in use", {}, 409);
      }
    }

    // Build update payload
    const updateData = { ...value, updated_by_id: req.user?.id || null };

    // ✅ Password update with history check
    if (value.password && value.password.trim() !== "") {
      // Fetch last 5 password hashes
      const lastHashes = await PasswordHistory.findAll({
        where: { user_id: user.id },
        order: [["created_at", "DESC"]],
        limit: 5,
      });

      // Check against old hashes
      for (const ph of lastHashes) {
        if (await bcrypt.compare(value.password, ph.password_hash)) {
          return error(res, "❌ Cannot reuse a recent password", {}, 400);
        }
      }

      // Hash new password
      updateData.password_hash = await bcrypt.hash(value.password, 10);

      // Store in password_history
      await PasswordHistory.create(
        { user_id: user.id, password_hash: updateData.password_hash },
        { transaction: t }
      );
    }
    delete updateData.password;

    // Perform update
    await user.update(updateData, { transaction: t });

    // Handle assignments
    if (Array.isArray(value.assignments) && value.assignments.length > 0) {
      if (scope === "organization") {
        const facilities = await Facility.findAll({
          where: { id: value.assignments.map((a) => a.facility_id) },
        });
        const invalid = facilities.some((f) => f.organization_id !== organization_id);
        if (invalid) {
          return error(res, "❌ Cannot reassign outside your organization", {}, 403);
        }
      }

      await UserFacility.destroy({ where: { user_id: user.id }, transaction: t });

      await Promise.all(
        value.assignments.map((a) =>
          UserFacility.create(
            {
              user_id: user.id,
              facility_id: a.facility_id,
              role_id: a.role_id,
              created_by_id: req.user?.id || null,
            },
            { transaction: t }
          )
        )
      );
    }

    await t.commit();

    // Reload fresh
    const fresh = await User.findByPk(user.id, {
      attributes: [
        "id",
        "username",
        "email",
        "first_name",
        "last_name",
        "status",
        "last_login_at",
        "organization_id",
      ],
      include: [
        {
          model: Facility,
          as: "facilities",
          attributes: ["id", "name", "code", "organization_id"],
          through: { attributes: [] },
        },
        {
          model: Role,
          as: "roles",
          attributes: ["id", "name", "requires_facility"],
          through: { attributes: [] },
        },
      ],
    });

    return success(res, "✅ User updated", fresh);
  } catch (err) {
    console.error("❌ updateUser error:", err);
    return error(res, "❌ Failed to update user", {}, 500);
  } finally {
    if (!t.finished) await t.rollback();
  }
};

/* ============================================================
   📌 DELETE USER
   ============================================================ */
export const deleteUser = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { scope, facility_id, organization_id } = resolveScope(req);
    const { id } = req.params;

    if (req.user.id === id) {
      return error(res, "❌ Cannot delete your own account", {}, 403);
    }

    console.log("🔎 [deleteUser] Incoming delete request for user ID:", id);

    // 🔎 Lookup outside of transaction, paranoid:false, safe includes
    const user = await User.findByPk(id, {
      paranoid: false,
      include: [
        {
          model: Facility,
          as: "facilities",
          attributes: ["id", "organization_id"],
          required: false,
        },
        {
          model: Role,
          as: "roles",
          attributes: ["id", "name"],
          through: { attributes: [] },
          required: false,
        },
      ],
    });

    if (!user) {
      console.warn(`⚠️ [deleteUser] User not found for ID: ${id}`);
      return error(res, `❌ User not found for ID ${id}`, {}, 404);
    }
    if (user.deleted_at) {
      console.warn(`⚠️ [deleteUser] User with ID ${id} already soft-deleted`);
    }

    // Scope checks
    if (scope === "facility") {
      const inFacility = user.facilities.some((f) => f.id === facility_id);
      if (!inFacility) {
        return error(res, "❌ Not authorized to delete this user", {}, 403);
      }
    } else if (scope === "organization") {
      const inOrg =
        user.organization_id === organization_id ||
        user.facilities.some((f) => f.organization_id === organization_id);
      if (!inOrg) {
        return error(res, "❌ Not authorized to delete this user", {}, 403);
      }
    }

    if (user.is_system) {
      return error(res, "❌ Cannot delete system accounts", {}, 403);
    }
    if (user.roles?.some((r) => r.name.toLowerCase().includes("superadmin"))) {
      return error(res, "❌ Cannot delete superadmin accounts", {}, 403);
    }

    // ✅ Perform delete inside transaction
    await user.update(
      { deleted_by_id: req.user?.id || null },
      { transaction: t }
    );
    await user.destroy({ transaction: t });

    await t.commit();
    return success(res, "✅ User deleted", { id });
  } catch (err) {
    console.error("❌ deleteUser error:", err);
    return error(res, "❌ Failed to delete user", {}, 500);
  } finally {
    if (!t.finished) await t.rollback();
  }
};

/* ============================================================
   📌 RESET PASSWORD TO DEFAULT (with PasswordHistory)
   ============================================================ */
export const resetUserPassword = async (req, res) => {
  try {
    const { scope, facility_id, organization_id } = resolveScope(req);
    const { id } = req.params;

    console.log("🔎 [resetUserPassword] Incoming reset request for user ID:", id);

    const user = await User.findByPk(id, {
      paranoid: false,
      attributes: ["id", "organization_id"],
      include: [
        {
          model: Facility,
          as: "facilities",
          attributes: ["id", "organization_id"],
          required: false, // ✅ don’t block if no facilities
        },
      ],
    });

    if (!user) {
      console.warn(`⚠️ [resetUserPassword] User not found for ID: ${id}`);
      return error(res, `❌ User not found for ID ${id}`, {}, 404);
    }

    // Scope enforcement
    if (scope === "facility") {
      const inFacility = user.facilities.some((f) => f.id === facility_id);
      if (!inFacility) {
        return error(res, "❌ Not authorized to reset password for this user", {}, 403);
      }
    } else if (scope === "organization") {
      const inOrg =
        user.organization_id === organization_id ||
        user.facilities.some((f) => f.organization_id === organization_id);
      if (!inOrg) {
        return error(res, "❌ Not authorized to reset password for this user", {}, 403);
      }
    }

    // 🔑 Generate a secure random temporary password
    const newPassword = `Temp-${crypto.randomBytes(4).toString("hex")}`;
    const newHash = await bcrypt.hash(newPassword, 10);

    user.password_hash = newHash;
    user.password_reset_token = null;
    user.password_reset_expiry = null;
    user.must_reset_password = true;

    // 🔓 Unlock account on reset
    user.login_attempts = 0;
    user.locked_until = null;

    user.updated_by_id = req.user?.id || null;
    await user.save();

    // 📌 Record in password_history
    await PasswordHistory.create({
      user_id: user.id,
      password_hash: newHash,
    });

    return success(
      res,
      "✅ Password reset to temporary and account unlocked",
      { id: user.id, tempPassword: newPassword }
    );
  } catch (err) {
    console.error("❌ resetUserPassword error:", err);
    return error(res, "❌ Failed to reset password", {}, 500);
  }
};

/* ============================================================
   📌 ADMIN GENERATE RESET TOKEN
   ============================================================ */
export const adminGenerateResetToken = async (req, res) => {
  try {
    const { scope, facility_id, organization_id } = resolveScope(req);
    const { user_id } = req.body;
    if (!user_id) return error(res, "❌ User ID is required", {}, 400);

    console.log("🔎 [adminGenerateResetToken] Incoming request for user ID:", user_id);

    const user = await User.findByPk(user_id, {
      paranoid: false,
      attributes: ["id", "organization_id"],
      include: [
        {
          model: Facility,
          as: "facilities",
          attributes: ["id", "organization_id"],
          required: false, // ✅ don’t block if no facility assigned
        },
      ],
    });

    if (!user) {
      console.warn(`⚠️ [adminGenerateResetToken] User not found for ID: ${user_id}`);
      return error(res, `❌ User not found for ID ${user_id}`, {}, 404);
    }

    // Scope enforcement
    if (scope === "facility") {
      const inFacility = user.facilities.some((f) => f.id === facility_id);
      if (!inFacility) return error(res, "❌ Not authorized", {}, 403);
    } else if (scope === "organization") {
      const inOrg =
        user.organization_id === organization_id ||
        user.facilities.some((f) => f.organization_id === organization_id);
      if (!inOrg) return error(res, "❌ Not authorized", {}, 403);
    }

    // 🔑 Ensure secret is defined
    const resetSecret = process.env.JWT_RESET_SECRET || process.env.JWT_SECRET;
    if (!resetSecret) {
      return error(res, "❌ Reset token secret not configured", {}, 500);
    }

    // ⏱️ If a valid token still exists, deny regeneration
    if (
      user.password_reset_token &&
      user.password_reset_expiry &&
      user.password_reset_expiry > new Date()
    ) {
      return error(
        res,
        "❌ Reset token already active. Wait until expiry or reset manually.",
        {},
        429
      );
    }

    const payload = { id: user.id, type: "password_reset" };
    const resetToken = jwt.sign(payload, resetSecret, { expiresIn: "30m" });

    user.password_reset_token = resetToken;
    user.password_reset_expiry = new Date(Date.now() + 30 * 60 * 1000);
    user.updated_by_id = req.user?.id || null;
    await user.save();

    return success(
      res,
      "✅ Reset token generated",
      { id: user.id, token: resetToken, exp: user.password_reset_expiry }
    );
  } catch (err) {
    console.error("❌ adminGenerateResetToken error:", err);
    return error(res, "❌ Failed to generate reset token", {}, 500);
  }
};

/* ============================================================
   📌 MANUAL PASSWORD RESET VIA TOKEN (with PasswordHistory)
   ============================================================ */
export const manualResetPassword = async (req, res) => {
  try {
    const { email, token, newPassword } = req.body;

    // 🔎 Validate input
    if (!email || !token || !newPassword) {
      return error(res, "❌ All fields (email, token, newPassword) are required", {}, 400);
    }

    // 🔑 Verify reset token secret
    const resetSecret = process.env.JWT_RESET_SECRET || process.env.JWT_SECRET;
    if (!resetSecret) {
      return error(res, "❌ Reset token secret not configured on server", {}, 500);
    }

    // 🔑 Verify and decode JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, resetSecret);
    } catch (e) {
      return error(res, "❌ Invalid or expired reset token", {}, 401);
    }

    // 🔍 Match DB record
    const user = await User.findOne({
      where: {
        email,
        id: decoded.id,
        password_reset_token: token,
        password_reset_expiry: { [Op.gt]: new Date() }, // not expired
      },
      paranoid: false,
    });

    if (!user) {
      console.warn(`⚠️ [manualResetPassword] No match for email=${email} token=${token}`);
      return error(res, "❌ Invalid or expired reset request", {}, 401);
    }

    // 🔒 Prevent password reuse — check last 5 history entries
    const lastHashes = await PasswordHistory.findAll({
      where: { user_id: user.id },
      order: [["created_at", "DESC"]],
      limit: 5,
    });

    for (const ph of lastHashes) {
      if (await bcrypt.compare(newPassword, ph.password_hash)) {
        return error(res, "❌ Cannot reuse one of your last 5 passwords", {}, 400);
      }
    }

    // 🔄 Hash and update password
    const newHash = await bcrypt.hash(newPassword, 10);

    user.password_hash = newHash;
    user.password_reset_token = null;
    user.password_reset_expiry = null;
    user.must_reset_password = false; // ✅ clear flag → allow login again
    user.login_attempts = 0;          // 🔓 unlock account
    user.locked_until = null;

    user.updated_by_id = req.user?.id || null; // may be null for self-service reset
    await user.save();

    // 📌 Insert into password_history for audit
    await PasswordHistory.create({
      user_id: user.id,
      password_hash: newHash,
    });

    return success(
      res,
      "✅ Password reset successful and account unlocked",
      { id: user.id, message: "Password updated" }
    );
  } catch (err) {
    console.error("❌ manualResetPassword error:", err);
    return error(res, "❌ Failed to reset password. Please try again later.", {}, 500);
  }
};

/* ============================================================
   📌 GET ALL USERS (Lite) – for dropdowns
   ============================================================ */
export const getAllUsersLite = async (req, res) => {
  try {
    const { scope, facility_id, organization_id } = resolveScope(req);

    const baseAttrs = ["id", "username", "email", "first_name", "last_name"];
    const baseOrder = [
      ["first_name", "ASC"],
      ["last_name", "ASC"],
      ["username", "ASC"],
    ];

    let users;

    if (scope === "superadmin") {
      // 🔹 Superadmins → see all active users
      // ✅ Optional filter by organization_id or facility_id
      const where = { status: "active" };

      if (req.query.organization_id) {
        where[Op.or] = [
          { organization_id: req.query.organization_id },
          { "$facilities.organization_id$": req.query.organization_id },
        ];
      }

      if (req.query.facility_id) {
        // override with specific facility
        where[Op.and] = [
          where,
          { "$facilities.id$": req.query.facility_id },
        ];
      }

      users = await User.findAll({
        where,
        attributes: baseAttrs,
        include: [
          {
            model: Facility,
            as: "facilities",
            attributes: ["id", "organization_id"],
            required: !!req.query.facility_id, // require join if filtering
            through: { attributes: [] },
          },
          {
            model: Role,
            as: "roles",
            attributes: ["id", "name", "requires_facility"],
            through: { attributes: [] },
          },
        ],
        order: baseOrder,
      });
    } else if (scope === "organization") {
      // 🔹 Active users directly in org OR via facilities in org
      users = await User.findAll({
        where: {
          status: "active",
          [Op.or]: [
            { organization_id },
            { "$facilities.organization_id$": organization_id },
          ],
        },
        attributes: baseAttrs,
        include: [
          {
            model: Facility,
            as: "facilities",
            attributes: ["id", "organization_id"],
            required: false,
            through: { attributes: [] },
          },
          {
            model: Role,
            as: "roles",
            attributes: ["id", "name", "requires_facility"],
            through: { attributes: [] },
          },
        ],
        order: baseOrder,
      });
    } else if (scope === "facility") {
      // 🔹 Only active users in this facility
      users = await User.findAll({
        where: { status: "active" },
        attributes: baseAttrs,
        include: [
          {
            model: Facility,
            as: "facilities",
            where: { id: facility_id },
            required: true,
            through: { attributes: [] },
          },
          {
            model: Role,
            as: "roles",
            attributes: ["id", "name", "requires_facility"],
            through: { attributes: [] },
          },
        ],
        order: baseOrder,
      });
    } else {
      return error(res, "❌ Not authorized to load users (lite)", {}, 403);
    }

    return success(res, "✅ Users loaded (lite)", users);
  } catch (err) {
    console.error("❌ getAllUsersLite error:", err);
    return error(res, "❌ Failed to load users (lite)", {}, 500);
  }
};


/* ============================================================
   📌 TOGGLE USER ROLE STATUS (via UserFacility)
   ============================================================ */
export const toggleUserRoleStatus = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { scope, facility_id, organization_id } = resolveScope(req);
    const { userId, facilityId, roleId } = req.params;

    const user = await User.findByPk(userId, {
      include: [
        { model: Facility, as: "facilities", attributes: ["id", "organization_id"] },
        { model: Role, as: "roles", attributes: ["id", "name"], through: { attributes: [] } }
      ],
      transaction: t,
    });
    if (!user) {
      return error(res, "❌ User not found", {}, 404);
    }

    const role = await Role.findByPk(roleId);
    if (!role) {
      return error(res, "❌ Role not found", {}, 404);
    }

    // 🔒 Protect critical accounts
    if (user.is_system) {
      return error(res, "❌ Cannot modify roles for system accounts", {}, 403);
    }
    if (user.roles?.some(r => r.name.toLowerCase().includes("superadmin"))) {
      return error(res, "❌ Cannot modify roles for superadmin accounts", {}, 403);
    }

    // 🔑 Enforce requires_facility rule
    if (role.requires_facility && !facilityId) {
      return error(res, "❌ This role requires a facility assignment", {}, 400);
    }
    if (!role.requires_facility && facilityId) {
      return error(res, "❌ This role cannot be tied to a facility", {}, 400);
    }

    // Scope enforcement
    if (scope === "facility") {
      if (facilityId !== facility_id) {
        return error(res, "❌ Not authorized to change roles in this facility", {}, 403);
      }
    } else if (scope === "organization") {
      if (facilityId) {
        const facility = await Facility.findByPk(facilityId);
        if (!facility || facility.organization_id !== organization_id) {
          return error(res, "❌ Not authorized to change roles in this organization", {}, 403);
        }
      } else if (user.organization_id !== organization_id) {
        return error(res, "❌ Not authorized to change roles in this organization", {}, 403);
      }
    }

    // Toggle role assignment
    const existing = await UserFacility.findOne({
      where: { user_id: userId, facility_id: facilityId || null, role_id: roleId },
      transaction: t,
    });

    if (existing) {
      await existing.destroy({ transaction: t });
      await t.commit();
      return success(res, "✅ Role removed from user", { removed: role.id });
    } else {
      await UserFacility.create(
        {
          user_id: userId,
          facility_id: facilityId || null,
          role_id: roleId,
          created_by_id: req.user?.id || null,
        },
        { transaction: t }
      );
      await t.commit();
      return success(res, "✅ Role added to user", { added: role.id });
    }
  } catch (err) {
    console.error("❌ toggleUserRoleStatus error:", err);
    return error(res, "❌ Failed to toggle role status", {}, 500);
  } finally {
    if (!t.finished) await t.rollback();
  }
};

/* ============================================================
   📌 LOGIN (with account lockout + must_reset_password check)
   ============================================================ */
export const login = async (req, res) => {
  try {
    const { usernameOrEmail, password } = req.body;

    const user = await User.findOne({
      where: {
        [Op.or]: [{ username: usernameOrEmail }, { email: usernameOrEmail }],
      },
      include: [
        {
          model: Role,
          as: "roles",
          attributes: ["id", "name", "requires_facility"],
          through: { attributes: [] },
        },
        {
          model: Facility,
          as: "facilities",
          attributes: ["id", "name", "organization_id"],
          through: { attributes: [] },
        },
      ],
    });

    if (!user) {
      return error(res, "❌ Invalid credentials", { code: "INVALID_CREDENTIALS" }, 401);
    }

    // 🔒 Protect critical accounts
    if (user.is_system) {
      return error(
        res,
        "❌ System accounts cannot be used to login",
        { code: "SYSTEM_ACCOUNT_LOGIN_FORBIDDEN" },
        403
      );
    }
    if (user.roles?.some((r) => r.name.toLowerCase().includes("superadmin"))) {
      return error(
        res,
        "❌ Superadmin accounts cannot login directly",
        { code: "SUPERADMIN_LOGIN_FORBIDDEN" },
        403
      );
    }

    // 🔒 Check lockout
    if (user.locked_until && user.locked_until > new Date()) {
      return error(
        res,
        `❌ Account locked. Try again after ${user.locked_until.toLocaleString()}`,
        { code: "ACCOUNT_LOCKED", locked_until: user.locked_until },
        403
      );
    }

    // ✅ Verify password
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      user.login_attempts += 1;

      if (user.login_attempts >= 5) {
        user.locked_until = new Date(Date.now() + 15 * 60 * 1000);
        await user.save();
        return error(
          res,
          "❌ Account locked for 15 minutes due to failed attempts",
          { code: "ACCOUNT_TEMP_LOCKED" },
          403
        );
      }

      await user.save();
      return error(res, "❌ Invalid credentials", { code: "INVALID_CREDENTIALS" }, 401);
    }

    // 🔒 If must_reset_password flag is set, deny login but return structured payload
    if (user.must_reset_password) {
      return error(
        res,
        "❌ You must reset your password before logging in",
        { code: "PASSWORD_RESET_REQUIRED", userId: user.id, email: user.email },
        403
      );
    }

    // ✅ Reset attempts after success
    user.login_attempts = 0;
    user.locked_until = null;
    user.last_login_at = new Date();
    await user.save();

    // 🔑 Issue JWT with richer payload
    const payload = {
      id: user.id,
      organization_id: user.organization_id,
      roles: user.roles.map((r) => ({
        id: r.id,
        name: r.name,
        requires_facility: r.requires_facility,
      })),
      facilities: user.facilities.map((f) => ({
        id: f.id,
        name: f.name,
        org: f.organization_id,
      })),
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: "1h" });

    return success(res, "✅ Login successful", { token, user: payload });
  } catch (err) {
    console.error("❌ login error:", err);
    return error(res, "❌ Failed to login", { code: "LOGIN_ERROR" }, 500);
  }
};

/* ============================================================
   📌 ADMIN UNLOCK USER (manual unlock)
   ============================================================ */
export const unlockUser = async (req, res) => {
  try {
    const { id } = req.params;

    if (req.user.id === id) {
      return error(res, "❌ You cannot unlock your own account", {}, 403);
    }

    const user = await User.findByPk(id, {
      include: [
        { model: Role, as: "roles", attributes: ["id", "name"], through: { attributes: [] } },
      ],
    });

    if (!user) return error(res, "❌ User not found", {}, 404);
    if (user.is_system) return error(res, "❌ Cannot unlock system accounts", {}, 403);
    if (user.roles?.some(r => r.name.toLowerCase().includes("superadmin"))) {
      return error(res, "❌ Cannot unlock superadmin accounts", {}, 403);
    }

    // 🔓 Reset lock state
    user.login_attempts = 0;
    user.locked_until = null;
    user.updated_by_id = req.user?.id || null;
    await user.save();

    return success(res, "✅ User account unlocked", { id: user.id });
  } catch (err) {
    console.error("❌ unlockUser error:", err);
    return error(res, "❌ Failed to unlock user", {}, 500);
  }
};

/* ============================================================
   📌 ADMIN REQUIRE PASSWORD RESET
   ============================================================ */
export const requirePasswordReset = async (req, res) => {
  try {
    const { id } = req.params;

    const user = await User.findByPk(id, {
      include: [
        { model: Role, as: "roles", attributes: ["id", "name"], through: { attributes: [] } },
      ],
    });

    if (!user) return error(res, "❌ User not found", {}, 404);
    if (user.is_system) return error(res, "❌ Cannot modify system accounts", {}, 403);
    if (user.roles?.some(r => r.name.toLowerCase().includes("superadmin"))) {
      return error(res, "❌ Cannot force password reset on superadmin accounts", {}, 403);
    }

    user.must_reset_password = true;
    user.updated_by_id = req.user?.id || null;
    await user.save();

    return success(res, "✅ User must reset password on next login", { id: user.id });
  } catch (err) {
    console.error("❌ requirePasswordReset error:", err);
    return error(res, "❌ Failed to require password reset", {}, 500);
  }
};
/* ============================================================
   📌 ADMIN REVOKE USER SESSIONS (logout all devices)
   ============================================================ */

export const revokeUserSessions = async (req, res) => {
  try {
    const { id } = req.params;

    if (req.user.id === id) {
      return error(res, "❌ Cannot revoke your own sessions here (use logoutAll)", {}, 403);
    }

    const user = await User.findByPk(id);
    if (!user) return error(res, "❌ User not found", {}, 404);
    if (user.is_system) return error(res, "❌ Cannot revoke sessions for system accounts", {}, 403);

    await RefreshToken.destroy({ where: { user_id: id } });

    return success(res, "✅ All sessions revoked for this user", { id });
  } catch (err) {
    console.error("❌ revokeUserSessions error:", err);
    return error(res, "❌ Failed to revoke user sessions", {}, 500);
  }
};
/* ============================================================
   📌 HARD DELETE USER (permanent purge)
   ============================================================ */
export const purgeUser = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;

    const user = await User.findByPk(id, { 
      paranoid: false,
      include: [
        {
          model: Role,
          as: "roles",
          attributes: ["id", "name"],
          through: { attributes: [] },
        },
      ],
    });

    if (!user) return error(res, "❌ User not found", {}, 404);

    if (user.is_system) {
      return error(res, "❌ Cannot purge system accounts", {}, 403);
    }
    if (user.roles?.some(r => r.name.toLowerCase().includes("superadmin"))) {
      return error(res, "❌ Cannot purge superadmin accounts", {}, 403);
    }

    await UserFacility.destroy({ where: { user_id: id }, transaction: t });
    await user.destroy({ force: true, transaction: t }); // 🔥 hard delete
    await t.commit();

    return success(res, "✅ User permanently deleted", { id });
  } catch (err) {
    if (!t.finished) await t.rollback();
    console.error("❌ purgeUser error:", err);
    return error(res, "❌ Failed to purge user", {}, 500);
  }
};
