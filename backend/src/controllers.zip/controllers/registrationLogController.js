// 📁 controllers/registrationLogController.js
import Joi from "joi";
import { Op } from "sequelize";
import {
  sequelize,
  RegistrationLog,
  Patient,
  Employee,
  Facility,
  Organization,
  User,
  Invoice,
  BillableItem,
  InvoiceItem
} from "../models/index.js";
import { success, error } from "../utils/response.js";
import { buildQueryOptions } from "../utils/queryHelper.js";
import { 
  REGISTRATION_LOG_STATUS, 
  REGISTRATION_METHODS, 
  REGISTRATION_CATEGORIES 
} from "../constants/enums.js";
import { authzService } from "../services/authzService.js";
import { auditService } from "../services/auditService.js";
import { FIELD_VISIBILITY_REGISTRATION_LOG } from "../constants/fieldVisibility.js";
import { billingService } from "../services/billingService.js";
import { shouldTriggerBilling, AUTO_BILLABLE_MODULES } from "../constants/billing.js";
import { isSuperAdmin } from "../utils/role-utils.js";

const MODULE_KEY = AUTO_BILLABLE_MODULES[0]; // "registration-log"

/* ============================================================
   🔗 SHARED INCLUDES
   ============================================================ */
const REGISTRATION_LOG_INCLUDES = [
  { model: Patient, as: "patient", attributes: ["id", "pat_no", "first_name", "last_name"] },
  { model: Employee.unscoped(), as: "registrar", attributes: ["id", "first_name", "last_name"] },
  { model: Invoice, as: "invoice", attributes: ["id", "invoice_number", "status", "total"] },
  { model: BillableItem, as: "registrationType", attributes: ["id", "name", "price"] },
  { model: Organization, as: "organization", attributes: ["id", "name", "code"] },
  { model: Facility, as: "facility", attributes: ["id", "name", "code", "organization_id"] },
  { model: User, as: "createdBy", attributes: ["id", "first_name", "last_name"] },
  { model: User, as: "updatedBy", attributes: ["id", "first_name", "last_name"] },
  { model: User, as: "deletedBy", attributes: ["id", "first_name", "last_name"] },
];

/* ============================================================
   📋 ROLE-BASED JOI SCHEMA FACTORY
   ============================================================ */
function buildRegistrationLogSchema(userRole, mode = "create") {
  const base = {
    patient_id: Joi.string().uuid().required(),
    registrar_id: Joi.string().uuid().allow(null, ""),
    organization_id: Joi.string().uuid().allow(null),
    facility_id: Joi.string().uuid().allow(null),
    invoice_id: Joi.string().uuid().allow(null),
    registration_type_id: Joi.string().uuid().allow(null),

    registration_method: Joi.string()
      .valid(...REGISTRATION_METHODS)
      .required(),
    registration_source: Joi.string().max(120).allow("", null),
    patient_category: Joi.string()
      .valid(...REGISTRATION_CATEGORIES)
      .required(),
    visit_reason: Joi.string().allow("", null),
    is_emergency: Joi.boolean().default(false),
    registration_time: Joi.date().default(() => new Date()),
    notes: Joi.string().allow("", null),

    log_status: Joi.string()
      .valid(...REGISTRATION_LOG_STATUS)
      .default(REGISTRATION_LOG_STATUS[0]),
  };

  // 🔁 Update mode → make all optional
  if (mode === "update") {
    Object.keys(base).forEach((k) => {
      base[k] = base[k].optional();
    });
  }

  // 🔐 Role-scoped field control (consistent with Appointment pattern)
  switch (userRole) {
    case "superadmin":
      // can explicitly pass org/fac
      break;

    case "org_owner":
      base.organization_id = Joi.forbidden();
      base.facility_id = Joi.string().uuid().allow(null); // ✅ allow backend injection
      break;

    case "admin":
      base.organization_id = Joi.forbidden();
      base.facility_id = Joi.string().uuid().required();
      break;

    case "facility_head":
    case "staff":
    default:
      base.organization_id = Joi.forbidden();
      base.facility_id = Joi.string().uuid().allow(null); // ✅ fixed: was forbidden
      break;
  }

  return Joi.object(base);
}

/* ============================================================
   📌 CREATE REGISTRATION LOG
   ============================================================ */
export const createRegistrationLog = async (req, res) => {
  const t = await sequelize.transaction();
  const MODULE_KEY = "registration_logs";

  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: MODULE_KEY,
      action: "create",
      res,
    });
    if (!allowed) return;

    const role = (req.user?.roleNames?.[0] || "").toLowerCase();
    const schema = buildRegistrationLogSchema(role, "create");
    const { error: validationError, value } = schema.validate(req.body, {
      stripUnknown: true,
    });

    if (validationError) {
      await t.rollback();
      return error(res, "Validation failed", validationError, 400);
    }

    // 🧭 Tenant Scope
    let orgId = req.user.organization_id || null;
    let facilityId = null;
    if (role === "superadmin") {
      orgId = value.organization_id || req.body.organization_id;
      facilityId = value.facility_id || req.body.facility_id || null;
    } else if (role === "org_owner") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id || null;
    } else if (role === "admin") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id;
    } else if (role === "facility_head") {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id;
    } else {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id || null;
    }

    if (!orgId) {
      await t.rollback();
      return error(res, "Missing organization assignment", null, 400);
    }

    // 👤 Registrar auto-link
    let registrarId = value.registrar_id || null;
    if (!registrarId && req.user?.employee_id) {
      registrarId = req.user.employee_id;
    }

    const created = await RegistrationLog.create(
      {
        ...value,
        registrar_id: registrarId,
        organization_id: orgId,
        facility_id: facilityId,
        created_by_id: req.user?.id || null,
      },
      { transaction: t }
    );

    await t.commit();

    const full = await RegistrationLog.findOne({
      where: { id: created.id },
      include: REGISTRATION_LOG_INCLUDES,
    });

    await auditService.logAction({
      user: req.user,
      module: MODULE_KEY,
      action: "create",
      entityId: created.id,
      entity: full,
      details: value,
    });

    return success(res, "✅ Registration Log created", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to create registration log", err);
  }
};

/* ============================================================
   📌 UPDATE REGISTRATION LOG
   ============================================================ */
export const updateRegistrationLog = async (req, res) => {
  const t = await sequelize.transaction();
  const MODULE_KEY = "registration_logs";

  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: MODULE_KEY,
      action: "update",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();
    const schema = buildRegistrationLogSchema(role, "update");
    const { error: validationError, value } = schema.validate(req.body, {
      stripUnknown: true,
    });

    if (validationError) {
      await t.rollback();
      return error(res, "Validation failed", validationError, 400);
    }

    // 🧭 Tenant Scope
    let orgId = req.user.organization_id || null;
    let facilityId = null;
    if (isSuperAdmin(req.user)) {
      orgId = value.organization_id || req.query.organization_id || null;
      facilityId = value.facility_id || req.query.facility_id || null;
    } else if (role === "org_owner") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id || null;
    } else if (role === "admin") {
      orgId = req.user.organization_id;
      facilityId = value.facility_id;
    } else if (role === "facility_head") {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id;
    } else {
      orgId = req.user.organization_id;
      facilityId = req.user.facility_id || null;
    }

    if (!orgId) {
      await t.rollback();
      return error(res, "Missing organization assignment", null, 400);
    }

    const log = await RegistrationLog.findOne({
      where: { id, organization_id: orgId },
      transaction: t,
    });

    if (!log) {
      await t.rollback();
      return error(res, "Registration Log not found", null, 404);
    }

    const oldStatus = log.log_status;

    // 👤 Registrar auto-link
    let registrarId = value.registrar_id || log.registrar_id || null;
    if (!registrarId && req.user?.employee_id) {
      registrarId = req.user.employee_id;
    }

    await log.update(
      {
        ...value,
        registrar_id: registrarId,
        organization_id: orgId,
        facility_id: facilityId,
        updated_by_id: req.user?.id || null,
      },
      { transaction: t }
    );

    // 💰 Only trigger billing on status transition
    if (
      oldStatus !== log.log_status &&
      shouldTriggerBilling(MODULE_KEY, log.log_status)
    ) {
      await billingService.triggerAutoBilling({
        module: MODULE_KEY,
        entity: log,
        user: { ...req.user, organization_id: orgId, facility_id: facilityId },
        transaction: t,
      });
    }

    await t.commit();

    const full = await RegistrationLog.findOne({
      where: { id },
      include: REGISTRATION_LOG_INCLUDES,
    });

    await auditService.logAction({
      user: req.user,
      module: MODULE_KEY,
      action: "update",
      entityId: id,
      entity: full,
      details: value,
    });

    return success(res, "✅ Registration Log updated", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to update registration log", err);
  }
};

/* ============================================================
   📌 GET ALL REGISTRATION LOGS
   ============================================================ */
export const getAllRegistrationLogs = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "registration_log",
      action: "read",
      res,
    });
    if (!allowed) return;

    const role = (req.user?.roleNames?.[0] || "staff").toLowerCase();
    const visibleFields = FIELD_VISIBILITY_REGISTRATION_LOG[role] || FIELD_VISIBILITY_REGISTRATION_LOG.staff;

    const options = buildQueryOptions(req, "registration_time", "DESC", visibleFields);
    options.where = options.where || {};

    if (!isSuperAdmin(req.user)) {
      options.where.organization_id = req.user.organization_id;
      if (role === "facility_head") options.where.facility_id = req.user.facility_id;
    } else {
      if (req.query.organization_id) options.where.organization_id = req.query.organization_id;
      if (req.query.facility_id) options.where.facility_id = req.query.facility_id;
    }

    if (options.search) {
      options.where[Op.or] = [
        { visit_reason: { [Op.iLike]: `%${options.search}%` } },
        { registration_source: { [Op.iLike]: `%${options.search}%` } },
      ];
    }

    const { count, rows } = await RegistrationLog.findAndCountAll({
      where: options.where,
      include: [...REGISTRATION_LOG_INCLUDES, ...(options.include || [])],
      order: options.order,
      offset: options.offset,
      limit: options.limit,
    });

    await auditService.logAction({
      user: req.user,
      module: "registration_log",
      action: "list",
      details: { query: req.query, returned: count },
    });

    return success(res, "✅ Registration Logs loaded", {
      records: rows,
      pagination: {
        total: count,
        page: options.pagination.page,
        pageCount: Math.ceil(count / options.pagination.limit),
      },
    });
  } catch (err) {
    return error(res, "❌ Failed to load registration logs", err);
  }
};

/* ============================================================
   📌 GET REGISTRATION LOG BY ID
   ============================================================ */
export const getRegistrationLogById = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "registration_log",
      action: "read",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "staff").toLowerCase();

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") where.facility_id = req.user.facility_id;
    } else {
      if (req.query.organization_id) where.organization_id = req.query.organization_id;
      if (req.query.facility_id) where.facility_id = req.query.facility_id;
    }

    const log = await RegistrationLog.findOne({ where, include: REGISTRATION_LOG_INCLUDES });
    if (!log) return error(res, "❌ Registration Log not found", null, 404);

    await auditService.logAction({
      user: req.user,
      module: "registration_log",
      action: "view",
      entityId: id,
      entity: log,
    });

    return success(res, "✅ Registration Log loaded", log);
  } catch (err) {
    return error(res, "❌ Failed to load registration log", err);
  }
};
/* ============================================================
   📌 GET ALL REGISTRATION LOGS LITE (with ?q= support)
   ============================================================ */
export const getAllRegistrationLogsLite = async (req, res) => {
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: "registration_log",
      action: "read",
      res,
    });
    if (!allowed) return;

    const { q } = req.query;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    // ✅ Explicit: only include ACTIVE logs
    const [DRAFT, PENDING, ACTIVE] = REGISTRATION_LOG_STATUS;
    const where = { log_status: ACTIVE };

    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") where.facility_id = req.user.facility_id;
    } else {
      if (req.query.organization_id) where.organization_id = req.query.organization_id;
      if (req.query.facility_id) where.facility_id = req.query.facility_id;
    }

    if (q) {
      where[Op.or] = [
        { registration_source: { [Op.iLike]: `%${q}%` } },
        { visit_reason: { [Op.iLike]: `%${q}%` } },
      ];
    }

    const logs = await RegistrationLog.findAll({
      where,
      attributes: ["id", "registration_time", "registration_source", "visit_reason"],
      include: [
        { model: Patient, as: "patient", attributes: ["id", "pat_no", "first_name", "last_name"] },
      ],
      order: [["registration_time", "DESC"]],
      limit: 20,
    });

    const result = logs.map(l => {
      const patientLabel = l.patient
        ? `${l.patient.pat_no} - ${l.patient.first_name} ${l.patient.last_name}`
        : "";

      const dateLabel = l.registration_time
        ? new Date(l.registration_time).toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
          })
        : "Unknown Date";

      return {
        id: l.id,
        label: `${dateLabel} · ${patientLabel} · ${l.visit_reason || "Visit"}`, // ✅ friendly label
        patient: patientLabel,
        source: l.registration_source || "",
        reason: l.visit_reason || "",
        time: l.registration_time,
      };
    });

    await auditService.logAction({
      user: req.user,
      module: "registration_log",
      action: "list_lite",
      details: { count: result.length, query: q || null, status: ACTIVE },
    });

    return success(res, "✅ Registration Logs loaded (lite)", { records: result });
  } catch (err) {
    return error(res, "❌ Failed to load registration logs (lite)", err);
  }
};

/* ============================================================
   📌 TOGGLE REGISTRATION LOG STATUS
   ============================================================ */
export const toggleRegistrationLogStatus = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: AUTO_BILLABLE_MODULES[0],
      action: "update",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") where.facility_id = req.user.facility_id;
    } else {
      if (req.query.organization_id) where.organization_id = req.query.organization_id;
      if (req.query.facility_id) where.facility_id = req.query.facility_id;
    }

    const log = await RegistrationLog.findOne({ where, transaction: t });
    if (!log) {
      await t.rollback();
      return error(res, "❌ Registration Log not found", null, 404);
    }

    const [DRAFT, PENDING, ACTIVE, COMPLETED, CANCELLED, VOIDED] = REGISTRATION_LOG_STATUS;
    const oldStatus = log.log_status;
    let newStatus;

    if (log.log_status === ACTIVE) newStatus = CANCELLED;
    else if (log.log_status === CANCELLED) newStatus = ACTIVE;
    else newStatus = log.log_status;

    await log.update({ log_status: newStatus, updated_by_id: req.user?.id || null }, { transaction: t });

    // ✅ Only bill if moved into a billable state and wasn’t already billed
    if (oldStatus !== newStatus && shouldTriggerBilling(AUTO_BILLABLE_MODULES[0], newStatus)) {
      const existing = await InvoiceItem.findOne({
        where: { module: AUTO_BILLABLE_MODULES[0], entity_id: log.id, status: "applied" },
        transaction: t,
      });
      if (!existing) {
        await billingService.triggerAutoBilling({
          module: AUTO_BILLABLE_MODULES[0],
          entity: log,
          user: { ...req.user, organization_id: log.organization_id, facility_id: log.facility_id },
          transaction: t,
        });
      }
    }

    // ❌ If toggled to cancel → rollback charges
    if (newStatus === CANCELLED) {
      await billingService.voidCharges({
        module: AUTO_BILLABLE_MODULES[0],
        entityId: log.id,
        user: { ...req.user, organization_id: log.organization_id, facility_id: log.facility_id },
        transaction: t,
      });
    }

    await t.commit();

    const full = await RegistrationLog.findOne({ where: { id }, include: REGISTRATION_LOG_INCLUDES });

    await auditService.logAction({
      user: req.user,
      module: AUTO_BILLABLE_MODULES[0],
      action: "toggle_status",
      entityId: id,
      entity: full,
      details: { from: oldStatus, to: newStatus },
    });

    return success(res, `✅ Registration Log status set to ${newStatus}`, full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to toggle registration log status", err);
  }
};

/* ============================================================
   📌 ACTIVATE REGISTRATION LOG (pending → active)
   ============================================================ */
export const activateRegistrationLog = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;
    const log = await RegistrationLog.findByPk(id, { transaction: t });
    if (!log) return error(res, "❌ Registration Log not found", null, 404);

    if (log.log_status !== "pending") {
      await t.rollback();
      return error(res, "❌ Only pending logs can be activated", null, 400);
    }

    const oldStatus = log.log_status;

    await log.update(
      { log_status: "active", updated_by_id: req.user?.id || null },
      { transaction: t }
    );

    // ✅ Only bill if status changed to active and not already billed
    if (oldStatus !== "active" && shouldTriggerBilling(AUTO_BILLABLE_MODULES[0], "active")) {
      const existing = await InvoiceItem.findOne({
        where: { module: AUTO_BILLABLE_MODULES[0], entity_id: log.id, status: "applied" },
        transaction: t,
      });
      if (!existing) {
        await billingService.triggerAutoBilling({
          module: AUTO_BILLABLE_MODULES[0],
          entity: log,
          user: { ...req.user, organization_id: log.organization_id, facility_id: log.facility_id },
          transaction: t,
        });
      }
    }

    await t.commit();

    // 🔄 Reload with full includes so frontend sees invoice + relations
    const full = await RegistrationLog.findOne({
      where: { id },
      include: REGISTRATION_LOG_INCLUDES,
    });

    await auditService.logAction({
      user: req.user,
      module: AUTO_BILLABLE_MODULES[0],
      action: "activate",
      entityId: id,
      entity: full,
      details: { from: oldStatus, to: "active" },
    });

    return success(res, "✅ Registration Log activated", full);
  } catch (err) {
    await t.rollback();
    console.error("[activateRegistrationLog] ❌ Error:", err); // 🪵 log full stack
    return error(res, "❌ Failed to activate registration log", err);
  }
};


/* ============================================================
   📌 DELETE REGISTRATION LOG (Soft Delete with Audit + Rollback Billing)
   ============================================================ */
export const deleteRegistrationLog = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const allowed = await authzService.checkPermission({
      user: req.user,
      module: AUTO_BILLABLE_MODULES[0],
      action: "delete",
      res,
    });
    if (!allowed) return;

    const { id } = req.params;
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();

    const where = { id };
    if (!isSuperAdmin(req.user)) {
      where.organization_id = req.user.organization_id;
      if (role === "facility_head") where.facility_id = req.user.facility_id;
    } else {
      if (req.query.organization_id) where.organization_id = req.query.organization_id;
      if (req.query.facility_id) where.facility_id = req.query.facility_id;
    }

    const log = await RegistrationLog.findOne({ where, transaction: t });
    if (!log) {
      await t.rollback();
      return error(res, "❌ Registration Log not found", null, 404);
    }

    // 🔒 Block delete if dependent records exist
    const consultations = await log.countConsultations({ transaction: t });
    const admissions = await log.countAdmissions({ transaction: t });
    const triages = await log.countTriageRecords({ transaction: t });
    if (consultations > 0 || admissions > 0 || triages > 0) {
      await t.rollback();
      return error(res, "❌ Cannot delete — downstream records exist", null, 400);
    }

    // ⚡ Rollback billing
    await billingService.voidCharges({
      module: AUTO_BILLABLE_MODULES[0],
      entityId: log.id,
      user: { ...req.user, organization_id: log.organization_id, facility_id: log.facility_id },
      transaction: t,
    });

    // 🔹 Soft delete
    await log.update({ deleted_by_id: req.user?.id || null }, { transaction: t });
    await log.destroy({ transaction: t });

    await t.commit();

    const full = await RegistrationLog.findOne({
      where: { id },
      include: REGISTRATION_LOG_INCLUDES,
      paranoid: false,
    });

    await auditService.logAction({
      user: req.user,
      module: AUTO_BILLABLE_MODULES[0],
      action: "delete",
      entityId: id,
      entity: full,
    });

    return success(res, "✅ Registration Log deleted (with billing rollback)", full);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to delete registration log", err);
  }
};

/* ============================================================
   📌 COMPLETE REGISTRATION LOG (active → completed)
   ============================================================ */
export const completeRegistrationLog = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;
    const log = await RegistrationLog.findByPk(id, { transaction: t });
    if (!log) return error(res, "❌ Registration Log not found", null, 404);

    if (log.log_status !== "active") {
      await t.rollback();
      return error(res, "❌ Only active logs can be completed", null, 400);
    }

    const oldStatus = log.log_status;

    await log.update(
      { log_status: "completed", updated_by_id: req.user?.id || null },
      { transaction: t }
    );

    // ✅ Only bill if status changed to completed and not already billed
    if (oldStatus !== "completed" && shouldTriggerBilling(AUTO_BILLABLE_MODULES[0], "completed")) {
      const existing = await InvoiceItem.findOne({
        where: { module: AUTO_BILLABLE_MODULES[0], entity_id: log.id, status: "applied" },
        transaction: t,
      });
      if (!existing) {
        await billingService.triggerAutoBilling({
          module: AUTO_BILLABLE_MODULES[0],
          entity: log,
          user: { ...req.user, organization_id: log.organization_id, facility_id: log.facility_id },
          transaction: t,
        });
      }
    }

    await t.commit();

    await auditService.logAction({
      user: req.user,
      module: AUTO_BILLABLE_MODULES[0],
      action: "complete",
      entityId: id,
      entity: log,
      details: { from: oldStatus, to: "completed" },
    });

    return success(res, "✅ Registration Log marked as completed", log);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to complete registration log", err);
  }
};

/* ============================================================
   📌 CANCEL REGISTRATION LOG (pending/active → cancelled)
   ============================================================ */
export const cancelRegistrationLog = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;
    const log = await RegistrationLog.findByPk(id, { transaction: t });
    if (!log) return error(res, "❌ Registration Log not found", null, 404);

    if (!["pending", "active"].includes(log.log_status)) {
      await t.rollback();
      return error(res, "❌ Only pending or active logs can be cancelled", null, 400);
    }

    await log.update({ log_status: "cancelled", updated_by_id: req.user?.id || null }, { transaction: t });

    await billingService.voidCharges({
      module: AUTO_BILLABLE_MODULES[0],
      entityId: log.id,
      user: { ...req.user, organization_id: log.organization_id, facility_id: log.facility_id },
      transaction: t,
    });

    await t.commit();

    await auditService.logAction({
      user: req.user,
      module: AUTO_BILLABLE_MODULES[0],
      action: "cancel",
      entityId: id,
      entity: log,
    });

    return success(res, "✅ Registration Log cancelled and charges voided", log);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to cancel registration log", err);
  }
};

/* ============================================================
   📌 VOID REGISTRATION LOG (any → voided, admin/superadmin only)
   ============================================================ */
export const voidRegistrationLog = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const role = (req.user?.roleNames?.[0] || "").toLowerCase();
    if (!["admin", "superadmin"].includes(role)) {
      return error(res, "❌ Only admin/superadmin can void logs", null, 403);
    }

    const { id } = req.params;
    const log = await RegistrationLog.findByPk(id, { transaction: t });
    if (!log) return error(res, "❌ Registration Log not found", null, 404);

    await log.update({ log_status: "voided", updated_by_id: req.user?.id || null }, { transaction: t });

    await billingService.voidCharges({
      module: AUTO_BILLABLE_MODULES[0],
      entityId: log.id,
      user: { ...req.user, organization_id: log.organization_id, facility_id: log.facility_id },
      transaction: t,
    });

    await t.commit();

    await auditService.logAction({
      user: req.user,
      module: AUTO_BILLABLE_MODULES[0],
      action: "void",
      entityId: id,
      entity: log,
    });

    return success(res, "✅ Registration Log voided and charges voided", log);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to void registration log", err);
  }
};

/* ============================================================
   📌 SUBMIT REGISTRATION LOG (draft → pending)
   ============================================================ */
export const submitRegistrationLog = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;

    // 🔍 Find the log
    const log = await RegistrationLog.findByPk(id, { transaction: t });
    if (!log) {
      await t.rollback();
      return error(res, "❌ Registration Log not found", null, 404);
    }

    // ⛔ Only allow submit if status is draft
    if (log.log_status !== REGISTRATION_LOG_STATUS[0]) { // "draft"
      await t.rollback();
      return error(res, "❌ Only draft logs can be submitted", null, 400);
    }

    // 🔄 Update status
    await log.update(
      { log_status: "pending", updated_by_id: req.user?.id || null },
      { transaction: t }
    );

    await t.commit();

    // 📝 Audit
    await auditService.logAction({
      user: req.user,
      module: AUTO_BILLABLE_MODULES[0],
      action: "submit",
      entityId: id,
      entity: log,
      details: { from: "draft", to: "pending" },
    });

    return success(res, "✅ Registration Log submitted (pending)", log);
  } catch (err) {
    await t.rollback();
    return error(res, "❌ Failed to submit registration log", err);
  }
};