// 📁 backend/src/db/migrations/0038_create-registration_logs.cjs
'use strict';

const { DataTypes } = require('sequelize');
const {
  REGISTRATION_LOG_STATUS,
  REGISTRATION_METHODS,
  REGISTRATION_CATEGORIES,
} = require('../../constants/enums.js');

module.exports = {
  async up(queryInterface) {
    await queryInterface.createTable('registration_logs', {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        primaryKey: true,
      },

      // 🔗 Foreign Keys
      patient_id: {
        type: DataTypes.UUID,
        allowNull: false,
        references: { model: 'patients', key: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
      },
      registrar_id: {
        type: DataTypes.UUID,
        allowNull: true,
        references: { model: 'employees', key: 'id' },
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      },
      organization_id: {
        type: DataTypes.UUID,
        allowNull: false,
        references: { model: 'organizations', key: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
      },
      facility_id: {
        type: DataTypes.UUID,
        allowNull: false,
        references: { model: 'facilities', key: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
      },
      invoice_id: {
        type: DataTypes.UUID,
        allowNull: true,
        references: { model: 'invoices', key: 'id' },
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      },
      registration_type_id: {
        // links to BillableItem representing the registration type
        type: DataTypes.UUID,
        allowNull: true,
        references: { model: 'billable_items', key: 'id' },
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      },

      // 📝 Info
      registration_method: {
        type: DataTypes.ENUM(...REGISTRATION_METHODS),
        allowNull: false,
        defaultValue: REGISTRATION_METHODS[0],
      },
      registration_source: { type: DataTypes.STRING(120), allowNull: true },
      patient_category: {
        type: DataTypes.ENUM(...REGISTRATION_CATEGORIES),
        allowNull: false,
        defaultValue: REGISTRATION_CATEGORIES[0],
      },
      visit_reason: { type: DataTypes.TEXT, allowNull: true },
      is_emergency: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
      registration_time: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
      notes: { type: DataTypes.TEXT, allowNull: true },

      // 🏷️ Lifecycle
      log_status: {
        type: DataTypes.ENUM(...REGISTRATION_LOG_STATUS),
        allowNull: false,
        defaultValue: REGISTRATION_LOG_STATUS[0],
      },

      // 🔹 Audit
      created_by_id: {
        type: DataTypes.UUID,
        allowNull: true,
        references: { model: 'users', key: 'id' },
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      },
      updated_by_id: {
        type: DataTypes.UUID,
        allowNull: true,
        references: { model: 'users', key: 'id' },
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      },
      deleted_by_id: {
        type: DataTypes.UUID,
        allowNull: true,
        references: { model: 'users', key: 'id' },
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      },

      // 🕒 Timestamps (paranoid)
      created_at: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
      updated_at: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
      deleted_at: { type: DataTypes.DATE, allowNull: true },
    });

    // 🔎 Indexes
    await queryInterface.addIndex('registration_logs', ['organization_id']);
    await queryInterface.addIndex('registration_logs', ['facility_id']);
    await queryInterface.addIndex('registration_logs', ['patient_id']);
    await queryInterface.addIndex('registration_logs', ['registrar_id']);
    await queryInterface.addIndex('registration_logs', ['invoice_id']);
    await queryInterface.addIndex('registration_logs', ['registration_type_id']);
    await queryInterface.addIndex('registration_logs', ['registration_time']);
    await queryInterface.addIndex('registration_logs', ['log_status']);
    await queryInterface.addIndex('registration_logs', ['is_emergency']);
  },

  async down(queryInterface) {
    await queryInterface.dropTable('registration_logs');
    // Optional Postgres enum cleanup:
    // await queryInterface.sequelize.query('DROP TYPE IF EXISTS "enum_registration_logs_registration_method";');
    // await queryInterface.sequelize.query('DROP TYPE IF EXISTS "enum_registration_logs_patient_category";');
    // await queryInterface.sequelize.query('DROP TYPE IF EXISTS "enum_registration_logs_log_status";');
  },
};
