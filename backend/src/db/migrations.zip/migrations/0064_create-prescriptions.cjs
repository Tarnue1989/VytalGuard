// 📁 migrations/0064_create-prescriptions.cjs
"use strict";

import { DataTypes } from "sequelize";
import { PRESCRIPTION_STATUS } from "../src/constants/enums.js";

export async function up(queryInterface) {
  await queryInterface.createTable("prescriptions", {
    id: {
      type: DataTypes.UUID,
      defaultValue: queryInterface.sequelize.literal("gen_random_uuid()"),
      primaryKey: true,
    },

    // 🔗 Tenant scope
    organization_id: { type: DataTypes.UUID, allowNull: false },
    facility_id: { type: DataTypes.UUID, allowNull: false },

    // Links
    consultation_id: { type: DataTypes.UUID },
    patient_id: { type: DataTypes.UUID, allowNull: false },
    doctor_id: { type: DataTypes.UUID, allowNull: false },
    department_id: { type: DataTypes.UUID },

    is_emergency: { type: DataTypes.BOOLEAN, defaultValue: false },
    notes: { type: DataTypes.TEXT },

    // Lifecycle
    status: {
      type: DataTypes.ENUM(...PRESCRIPTION_STATUS),
      allowNull: false,
      defaultValue: PRESCRIPTION_STATUS[0], // "draft"
    },

    fulfilled_by: { type: DataTypes.UUID },
    fulfilled_at: { type: DataTypes.DATE },

    // Audit
    created_by_id: { type: DataTypes.UUID },
    updated_by_id: { type: DataTypes.UUID },
    deleted_by_id: { type: DataTypes.UUID },

    // Sequelize timestamps
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    deleted_at: { type: DataTypes.DATE },
  });

  // Indexes
  await queryInterface.addIndex("prescriptions", ["organization_id"]);
  await queryInterface.addIndex("prescriptions", ["facility_id"]);
  await queryInterface.addIndex("prescriptions", ["patient_id"]);
  await queryInterface.addIndex("prescriptions", ["doctor_id"]);
  await queryInterface.addIndex("prescriptions", ["status"]);
}

export async function down(queryInterface) {
  await queryInterface.dropTable("prescriptions");
}
