// 📁 migrations/0060_create-maternity_visits.cjs
"use strict";

import { DataTypes } from "sequelize";
import { MATERNITY_VISIT_STATUS } from "../src/constants/enums.js";

export async function up(queryInterface) {
  await queryInterface.createTable("maternity_visits", {
    id: {
      type: DataTypes.UUID,
      defaultValue: queryInterface.sequelize.literal("gen_random_uuid()"),
      primaryKey: true,
    },

    // 🔗 Tenant scope
    organization_id: { type: DataTypes.UUID, allowNull: false },
    facility_id: { type: DataTypes.UUID, allowNull: false },

    // 🔗 Links
    patient_id: { type: DataTypes.UUID, allowNull: false },
    doctor_id: { type: DataTypes.UUID },
    midwife_id: { type: DataTypes.UUID },
    department_id: { type: DataTypes.UUID },
    consultation_id: { type: DataTypes.UUID },
    billable_item_id: { type: DataTypes.UUID },
    invoice_id: { type: DataTypes.UUID },

    // 📅 Visit info
    visit_date: { type: DataTypes.DATEONLY, allowNull: false },
    visit_type: { type: DataTypes.STRING },

    // 🤰 Maternal observations
    lnmp: { type: DataTypes.DATE },
    expected_due_date: { type: DataTypes.DATE },
    estimated_gestational_age: { type: DataTypes.STRING },
    fundus_height: { type: DataTypes.STRING },
    fetal_heart_rate: { type: DataTypes.STRING },
    presentation: { type: DataTypes.STRING },
    position: { type: DataTypes.STRING },
    complaint: { type: DataTypes.TEXT },
    gravida: { type: DataTypes.INTEGER },
    para: { type: DataTypes.STRING },
    abortion: { type: DataTypes.INTEGER },
    living: { type: DataTypes.INTEGER },
    visit_notes: { type: DataTypes.TEXT },

    // 🩺 Vitals
    blood_pressure: { type: DataTypes.STRING },
    weight: { type: DataTypes.STRING },
    height: { type: DataTypes.STRING },
    temperature: { type: DataTypes.STRING },
    pulse_rate: { type: DataTypes.STRING },

    // 🚨 Flags & Lifecycle
    is_emergency: { type: DataTypes.BOOLEAN, defaultValue: false },
    status: {
      type: DataTypes.ENUM(...MATERNITY_VISIT_STATUS),
      allowNull: false,
      defaultValue: MATERNITY_VISIT_STATUS[0], // "scheduled"
    },

    // 📌 Status workflow dates
    finalized_at: { type: DataTypes.DATE },
    finalized_by_id: { type: DataTypes.UUID },
    verified_by_id: { type: DataTypes.UUID },

    // 🕵🏽 Audit trail
    created_by_id: { type: DataTypes.UUID },
    updated_by_id: { type: DataTypes.UUID },
    deleted_by_id: { type: DataTypes.UUID },

    // Sequelize timestamps
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    deleted_at: { type: DataTypes.DATE },
  });

  // Indexes
  await queryInterface.addIndex("maternity_visits", ["organization_id"]);
  await queryInterface.addIndex("maternity_visits", ["facility_id"]);
  await queryInterface.addIndex("maternity_visits", ["patient_id"]);
  await queryInterface.addIndex("maternity_visits", ["visit_date"]);
  await queryInterface.addIndex("maternity_visits", ["status"]);
  await queryInterface.addIndex("maternity_visits", ["midwife_id"]);
  await queryInterface.addIndex("maternity_visits", ["visit_type"]);
  await queryInterface.addIndex("maternity_visits", ["invoice_id"]);
}

export async function down(queryInterface) {
  await queryInterface.dropTable("maternity_visits");
}
