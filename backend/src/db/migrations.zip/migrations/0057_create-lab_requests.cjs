// 📁 migrations/0057_create-lab_requests.cjs
"use strict";

import { DataTypes } from "sequelize";
import { LAB_REQUEST_STATUS } from "../src/constants/enums.js";

export async function up(queryInterface) {
  await queryInterface.createTable("lab_requests", {
    id: {
      type: DataTypes.UUID,
      defaultValue: queryInterface.sequelize.literal("gen_random_uuid()"),
      primaryKey: true,
    },

    // 🔗 Tenant scope
    organization_id: { type: DataTypes.UUID, allowNull: false },
    facility_id: { type: DataTypes.UUID, allowNull: false },

    patient_id: { type: DataTypes.UUID, allowNull: false },
    doctor_id: { type: DataTypes.UUID, allowNull: false },
    department_id: { type: DataTypes.UUID },
    consultation_id: { type: DataTypes.UUID },
    lab_test_id: { type: DataTypes.UUID, allowNull: false },
    invoice_id: { type: DataTypes.UUID },

    request_date: { type: DataTypes.DATEONLY, allowNull: false },

    // Lifecycle
    status: {
      type: DataTypes.ENUM(...LAB_REQUEST_STATUS),
      allowNull: false,
      defaultValue: LAB_REQUEST_STATUS[0], // "draft"
    },

    notes: { type: DataTypes.TEXT },
    is_emergency: { type: DataTypes.BOOLEAN, defaultValue: false },
    billed: { type: DataTypes.BOOLEAN, defaultValue: false },

    // Audit
    created_by_id: { type: DataTypes.UUID },
    updated_by_id: { type: DataTypes.UUID },
    deleted_by_id: { type: DataTypes.UUID },

    // Sequelize timestamps
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    deleted_at: { type: DataTypes.DATE },
  });

  // Indexes
  await queryInterface.addIndex("lab_requests", ["organization_id"]);
  await queryInterface.addIndex("lab_requests", ["facility_id"]);
  await queryInterface.addIndex("lab_requests", ["patient_id"]);
  await queryInterface.addIndex("lab_requests", ["doctor_id"]);
  await queryInterface.addIndex("lab_requests", ["lab_test_id"]);
  await queryInterface.addIndex("lab_requests", ["status"]);

  // Unique constraint: one lab test per patient per day
  await queryInterface.addConstraint("lab_requests", {
    fields: ["patient_id", "lab_test_id", "request_date"],
    type: "unique",
    name: "unique_lab_request_per_day",
  });
}

export async function down(queryInterface) {
  await queryInterface.dropTable("lab_requests");
}
