// 📁 migrations/0072_create-wards.cjs
"use strict";

import { DataTypes } from "sequelize";
import { WARD_STATUS } from "../src/constants/enums.js";

export async function up(queryInterface) {
  await queryInterface.createTable("wards", {
    id: {
      type: DataTypes.UUID,
      defaultValue: queryInterface.sequelize.literal("gen_random_uuid()"),
      primaryKey: true,
    },

    // Tenant scope
    organization_id: { type: DataTypes.UUID, allowNull: false },
    facility_id: { type: DataTypes.UUID, allowNull: false },
    department_id: { type: DataTypes.UUID },

    name: { type: DataTypes.STRING(100), allowNull: false },
    description: { type: DataTypes.TEXT },

    // Lifecycle
    status: {
      type: DataTypes.ENUM(...WARD_STATUS),
      allowNull: false,
      defaultValue: WARD_STATUS[0], // "active"
    },

    // Audit
    created_by_id: { type: DataTypes.UUID },
    updated_by_id: { type: DataTypes.UUID },
    deleted_by_id: { type: DataTypes.UUID },

    // Sequelize timestamps
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    deleted_at: { type: DataTypes.DATE },
  });

  // Indexes
  await queryInterface.addIndex("wards", ["organization_id"]);
  await queryInterface.addIndex("wards", ["facility_id"]);
  await queryInterface.addIndex("wards", ["department_id"]);
  await queryInterface.addIndex("wards", ["status"]);

  // Unique constraint
  await queryInterface.addConstraint("wards", {
    fields: ["organization_id", "facility_id", "name"],
    type: "unique",
    name: "unique_ward_per_facility",
  });
}

export async function down(queryInterface) {
  await queryInterface.dropTable("wards");
}
