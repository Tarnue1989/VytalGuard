// 📁 migrations/0047_create-appointments.cjs
"use strict";

import { DataTypes } from "sequelize";
import { APPOINTMENT_STATUS } from "../src/constants/enums.js";

export async function up(queryInterface) {
  await queryInterface.createTable("appointments", {
    id: {
      type: DataTypes.UUID,
      defaultValue: queryInterface.sequelize.literal("gen_random_uuid()"),
      primaryKey: true,
    },

    // 🔗 Tenant scope
    organization_id: { type: DataTypes.UUID, allowNull: false },
    facility_id: { type: DataTypes.UUID, allowNull: false },

    appointment_code: { type: DataTypes.STRING(50), allowNull: false, unique: true },

    patient_id: { type: DataTypes.UUID, allowNull: false },
    doctor_id: { type: DataTypes.UUID, allowNull: false },
    department_id: { type: DataTypes.UUID },

    date_time: { type: DataTypes.DATE, allowNull: false },

    // Lifecycle
    status: {
      type: DataTypes.ENUM(...APPOINTMENT_STATUS),
      allowNull: false,
      defaultValue: APPOINTMENT_STATUS[0], // "scheduled"
    },

    notes: { type: DataTypes.TEXT },

    // Audit
    created_by_id: { type: DataTypes.UUID },
    updated_by_id: { type: DataTypes.UUID },
    deleted_by_id: { type: DataTypes.UUID },

    // Sequelize timestamps
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    deleted_at: { type: DataTypes.DATE },
  });

  // Indexes
  await queryInterface.addIndex("appointments", ["organization_id"]);
  await queryInterface.addIndex("appointments", ["facility_id"]);
  await queryInterface.addIndex("appointments", ["patient_id"]);
  await queryInterface.addIndex("appointments", ["doctor_id"]);
  await queryInterface.addIndex("appointments", ["date_time"]);
  await queryInterface.addIndex("appointments", ["status"]);
}

export async function down(queryInterface) {
  await queryInterface.dropTable("appointments");
}
