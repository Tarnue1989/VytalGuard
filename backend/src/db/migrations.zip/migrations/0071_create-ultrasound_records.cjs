// 📁 migrations/0071_create-ultrasound_records.cjs
"use strict";

import { DataTypes } from "sequelize";
import { ULTRASOUND_STATUS } from "../src/constants/enums.js";

export async function up(queryInterface) {
  await queryInterface.createTable("ultrasound_records", {
    id: {
      type: DataTypes.UUID,
      defaultValue: queryInterface.sequelize.literal("gen_random_uuid()"),
      primaryKey: true,
    },

    // Tenant scope
    organization_id: { type: DataTypes.UUID, allowNull: false },
    facility_id: { type: DataTypes.UUID, allowNull: false },

    // Links
    patient_id: { type: DataTypes.UUID, allowNull: false },
    consultation_id: { type: DataTypes.UUID },
    maternity_visit_id: { type: DataTypes.UUID },
    registration_log_id: { type: DataTypes.UUID },
    department_id: { type: DataTypes.UUID },
    billable_item_id: { type: DataTypes.UUID }, // ✅ renamed
    technician_id: { type: DataTypes.UUID },
    verified_by_id: { type: DataTypes.UUID },

    // Scan details
    scan_type: { type: DataTypes.STRING, allowNull: false },
    scan_date: { type: DataTypes.DATE, allowNull: false },
    scan_location: { type: DataTypes.STRING },

    // Medical observations
    ultra_findings: { type: DataTypes.TEXT },
    note: { type: DataTypes.TEXT },
    number_of_fetus: { type: DataTypes.INTEGER },
    biparietal_diameter: { type: DataTypes.STRING },
    presentation: { type: DataTypes.STRING },
    lie: { type: DataTypes.STRING },
    position: { type: DataTypes.STRING },
    amniotic_volume: { type: DataTypes.STRING },
    fetal_heart_rate: { type: DataTypes.STRING },
    gender: { type: DataTypes.STRING },

    // Obstetric specific
    ultrasound_done: { type: DataTypes.BOOLEAN, defaultValue: false },
    previous_cesarean: { type: DataTypes.BOOLEAN, defaultValue: false },
    prev_ces_date: { type: DataTypes.DATE },
    prev_ces_location: { type: DataTypes.STRING },
    cesarean_date: { type: DataTypes.DATE },
    indication: { type: DataTypes.STRING },
    next_of_kin: { type: DataTypes.STRING },

    // Lifecycle
    is_emergency: { type: DataTypes.BOOLEAN, defaultValue: false },
    status: {
      type: DataTypes.ENUM(...ULTRASOUND_STATUS),
      allowNull: false,
      defaultValue: ULTRASOUND_STATUS[0], // "pending"
    },
    source: { type: DataTypes.STRING },
    file_path: { type: DataTypes.TEXT },

    // Audit
    created_by_id: { type: DataTypes.UUID },
    updated_by_id: { type: DataTypes.UUID },
    deleted_by_id: { type: DataTypes.UUID },

    // Sequelize timestamps
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    deleted_at: { type: DataTypes.DATE },
  });

  // Indexes
  await queryInterface.addIndex("ultrasound_records", ["organization_id"]);
  await queryInterface.addIndex("ultrasound_records", ["facility_id"]);
  await queryInterface.addIndex("ultrasound_records", ["patient_id"]);
  await queryInterface.addIndex("ultrasound_records", ["scan_date"]);
  await queryInterface.addIndex("ultrasound_records", ["status"]);
  await queryInterface.addIndex("ultrasound_records", ["technician_id"]);
  await queryInterface.addIndex("ultrasound_records", ["registration_log_id"]);
}

export async function down(queryInterface) {
  await queryInterface.dropTable("ultrasound_records");
}
