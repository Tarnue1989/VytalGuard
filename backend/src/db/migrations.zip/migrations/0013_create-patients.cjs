// 📁 backend/src/db/migrations/0013_create-patients.cjs
"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("patients", {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.literal("gen_random_uuid()"),
        primaryKey: true,
      },

      // 🆔 Core details
      pat_no: { type: Sequelize.STRING(50), allowNull: false, unique: true },
      first_name: { type: Sequelize.STRING(120), allowNull: false },
      middle_name: { type: Sequelize.STRING(120), allowNull: true },
      last_name: { type: Sequelize.STRING(120), allowNull: false },
      date_of_birth: { type: Sequelize.DATEONLY, allowNull: true },
      gender: { type: Sequelize.ENUM("Male", "Female"), allowNull: true },
      phone_number: { type: Sequelize.STRING(50), allowNull: true },
      email_address: { type: Sequelize.STRING(120), allowNull: true },
      home_address: { type: Sequelize.STRING(255), allowNull: true },
      marital_status: { type: Sequelize.STRING(50), allowNull: true },
      religion: { type: Sequelize.STRING(80), allowNull: true },
      profession: { type: Sequelize.STRING(120), allowNull: true },

      // 🚨 Emergency Contact
      emergency_contact_name: { type: Sequelize.STRING(120), allowNull: true },
      emergency_contact_phone: { type: Sequelize.STRING(50), allowNull: true },

      // 📝 Registration
      registration_status: { type: Sequelize.STRING(50), allowNull: true },
      source_of_registration: { type: Sequelize.STRING(120), allowNull: true },
      notes: { type: Sequelize.TEXT, allowNull: true },

      // 📷 Media
      qr_code_path: { type: Sequelize.STRING(255), allowNull: true },
      photo_path: { type: Sequelize.STRING(255), allowNull: true },

      // 🔗 Links
      organization_id: { type: Sequelize.UUID, allowNull: false },
      facility_id: { type: Sequelize.UUID, allowNull: true },
      employee_id: { type: Sequelize.UUID, allowNull: true },

      // 🔹 Audit
      created_by_id: { type: Sequelize.UUID, allowNull: true },
      updated_by_id: { type: Sequelize.UUID, allowNull: true },
      deleted_by_id: { type: Sequelize.UUID, allowNull: true },

      // 🕒 Timestamps
      created_at: { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.literal("CURRENT_TIMESTAMP") },
      updated_at: { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.literal("CURRENT_TIMESTAMP") },
      deleted_at: { type: Sequelize.DATE, allowNull: true },
    });

    // Indexes
    await queryInterface.addIndex("patients", ["pat_no"]);
    await queryInterface.addIndex("patients", ["organization_id"]);
    await queryInterface.addIndex("patients", ["facility_id"]);
    await queryInterface.addIndex("patients", ["employee_id"]);
  },

  async down(queryInterface) {
    await queryInterface.dropTable("patients");
  },
};
