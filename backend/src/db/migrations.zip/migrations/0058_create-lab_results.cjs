// 📁 migrations/0058_create-lab_results.cjs
"use strict";

import { DataTypes } from "sequelize";
import { LAB_RESULT_STATUS } from "../src/constants/enums.js";

export async function up(queryInterface) {
  await queryInterface.createTable("lab_results", {
    id: {
      type: DataTypes.UUID,
      defaultValue: queryInterface.sequelize.literal("gen_random_uuid()"),
      primaryKey: true,
    },

    // 🔗 Tenant scope
    organization_id: { type: DataTypes.UUID, allowNull: false },
    facility_id: { type: DataTypes.UUID, allowNull: false },

    // Links
    lab_request_id: { type: DataTypes.UUID, allowNull: false },
    department_id: { type: DataTypes.UUID },
    billable_item_id: { type: DataTypes.UUID }, // ✅ renamed
    doctor_id: { type: DataTypes.UUID },
    consultation_id: { type: DataTypes.UUID },

    // 📋 Result details
    result: { type: DataTypes.TEXT, allowNull: false },
    notes: { type: DataTypes.TEXT },
    doctor_notes: { type: DataTypes.TEXT },
    result_date: { type: DataTypes.DATEONLY },
    attachment_url: { type: DataTypes.STRING },

    // Lifecycle
    status: {
      type: DataTypes.ENUM(...LAB_RESULT_STATUS),
      allowNull: false,
      defaultValue: LAB_RESULT_STATUS[0], // "draft"
    },

    reviewed_at: { type: DataTypes.DATE },
    verified_at: { type: DataTypes.DATE },

    // Audit
    entered_by_id: { type: DataTypes.UUID },
    reviewed_by_id: { type: DataTypes.UUID },
    verified_by_id: { type: DataTypes.UUID },
    created_by_id: { type: DataTypes.UUID },
    updated_by_id: { type: DataTypes.UUID },
    deleted_by_id: { type: DataTypes.UUID },

    // Sequelize timestamps
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    deleted_at: { type: DataTypes.DATE },
  });

  // Indexes
  await queryInterface.addIndex("lab_results", ["organization_id"]);
  await queryInterface.addIndex("lab_results", ["facility_id"]);
  await queryInterface.addIndex("lab_results", ["lab_request_id"]);
  await queryInterface.addIndex("lab_results", ["doctor_id"]);
  await queryInterface.addIndex("lab_results", ["result_date"]);
  await queryInterface.addIndex("lab_results", ["status"]);
}

export async function down(queryInterface) {
  await queryInterface.dropTable("lab_results");
}
