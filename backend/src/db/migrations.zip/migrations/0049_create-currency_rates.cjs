// 📁 migrations/0049_create-currency_rates.cjs
"use strict";

import { DataTypes } from "sequelize";
import { CURRENCY_RATE_STATUS } from "../src/constants/enums.js";

export async function up(queryInterface) {
  await queryInterface.createTable("currency_rates", {
    id: {
      type: DataTypes.UUID,
      defaultValue: queryInterface.sequelize.literal("gen_random_uuid()"),
      primaryKey: true,
    },

    // 🔗 Tenant scope
    organization_id: { type: DataTypes.UUID, allowNull: false },
    facility_id: { type: DataTypes.UUID, allowNull: false },

    from_currency: { type: DataTypes.STRING(10), allowNull: false },
    to_currency: { type: DataTypes.STRING(10), allowNull: false },
    rate: { type: DataTypes.DECIMAL(12, 6), allowNull: false },
    effective_date: { type: DataTypes.DATEONLY, allowNull: false, defaultValue: queryInterface.sequelize.literal("CURRENT_DATE") },

    // Lifecycle
    status: {
      type: DataTypes.ENUM(...CURRENCY_RATE_STATUS),
      allowNull: false,
      defaultValue: CURRENCY_RATE_STATUS[0], // "active"
    },

    // Audit
    created_by_id: { type: DataTypes.UUID },
    updated_by_id: { type: DataTypes.UUID },
    deleted_by_id: { type: DataTypes.UUID },

    // Sequelize timestamps
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    deleted_at: { type: DataTypes.DATE },
  });

  // Indexes
  await queryInterface.addIndex("currency_rates", ["organization_id"]);
  await queryInterface.addIndex("currency_rates", ["facility_id"]);
  await queryInterface.addIndex("currency_rates", ["from_currency", "to_currency"]);
  await queryInterface.addIndex("currency_rates", ["effective_date"]);
  await queryInterface.addIndex("currency_rates", ["status"]);

  // Unique constraint: only one rate per day per currency pair in a facility
  await queryInterface.addConstraint("currency_rates", {
    fields: ["organization_id", "facility_id", "from_currency", "to_currency", "effective_date"],
    type: "unique",
    name: "unique_rate_per_day",
  });
}

export async function down(queryInterface) {
  await queryInterface.dropTable("currency_rates");
}
