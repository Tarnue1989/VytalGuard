// 📁 migrations/0063_create-pharmacy_transactions.cjs
"use strict";

import { DataTypes } from "sequelize";
import { PHARMACY_TRANSACTION_STATUS } from "../src/constants/enums.js";

export async function up(queryInterface) {
  await queryInterface.createTable("pharmacy_transactions", {
    id: {
      type: DataTypes.UUID,
      defaultValue: queryInterface.sequelize.literal("gen_random_uuid()"),
      primaryKey: true,
    },

    // 🔗 Tenant scope
    organization_id: { type: DataTypes.UUID, allowNull: false },
    facility_id: { type: DataTypes.UUID, allowNull: false },

    patient_id: { type: DataTypes.UUID },
    prescription_id: { type: DataTypes.UUID },
    prescription_item_id: { type: DataTypes.UUID },
    consultation_id: { type: DataTypes.UUID },
    department_id: { type: DataTypes.UUID },

    medication_id: { type: DataTypes.UUID, allowNull: false },
    quantity_dispensed: { type: DataTypes.INTEGER, allowNull: false },

    type: {
      type: DataTypes.ENUM("dispense", "return", "adjustment"),
      allowNull: false,
    },

    // Lifecycle
    status: {
      type: DataTypes.ENUM(...PHARMACY_TRANSACTION_STATUS),
      allowNull: false,
      defaultValue: PHARMACY_TRANSACTION_STATUS[0], // "pending"
    },

    is_emergency: { type: DataTypes.BOOLEAN, defaultValue: false },
    notes: { type: DataTypes.TEXT },

    fulfilled_by_id: { type: DataTypes.UUID },
    fulfillment_date: { type: DataTypes.DATE },

    void_reason: { type: DataTypes.STRING },
    voided_by_id: { type: DataTypes.UUID },
    voided_at: { type: DataTypes.DATE },

    // Audit
    created_by_id: { type: DataTypes.UUID },
    updated_by_id: { type: DataTypes.UUID },
    deleted_by_id: { type: DataTypes.UUID },

    // Sequelize timestamps
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    deleted_at: { type: DataTypes.DATE },
  });

  // Indexes
  await queryInterface.addIndex("pharmacy_transactions", ["organization_id"]);
  await queryInterface.addIndex("pharmacy_transactions", ["facility_id"]);
  await queryInterface.addIndex("pharmacy_transactions", ["patient_id"]);
  await queryInterface.addIndex("pharmacy_transactions", ["prescription_id"]);
  await queryInterface.addIndex("pharmacy_transactions", ["prescription_item_id"]);
  await queryInterface.addIndex("pharmacy_transactions", ["medication_id"]);
  await queryInterface.addIndex("pharmacy_transactions", ["fulfilled_by_id"]);
  await queryInterface.addIndex("pharmacy_transactions", ["voided_by_id"]);
  await queryInterface.addIndex("pharmacy_transactions", ["consultation_id"]);
  await queryInterface.addIndex("pharmacy_transactions", ["department_id"]);
  await queryInterface.addIndex("pharmacy_transactions", ["status"]);
  await queryInterface.addIndex("pharmacy_transactions", ["type"]);
}

export async function down(queryInterface) {
  await queryInterface.dropTable("pharmacy_transactions");
}
