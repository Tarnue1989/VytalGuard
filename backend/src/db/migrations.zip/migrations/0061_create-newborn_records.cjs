// 📁 migrations/0061_create-newborn_records.cjs
"use strict";

import { DataTypes } from "sequelize";
import { NEWBORN_STATUS, GENDER_TYPES } from "../src/constants/enums.js";

export async function up(queryInterface) {
  await queryInterface.createTable("newborn_records", {
    id: {
      type: DataTypes.UUID,
      defaultValue: queryInterface.sequelize.literal("gen_random_uuid()"),
      primaryKey: true,
    },

    // Tenant scope
    organization_id: { type: DataTypes.UUID, allowNull: false },
    facility_id: { type: DataTypes.UUID, allowNull: false },

    // Links
    mother_id: { type: DataTypes.UUID, allowNull: false },
    delivery_record_id: { type: DataTypes.UUID, allowNull: false },

    // Baby details
    gender: { type: DataTypes.ENUM(...GENDER_TYPES), allowNull: false },
    birth_weight: { type: DataTypes.STRING },
    birth_length: { type: DataTypes.STRING },
    head_circumference: { type: DataTypes.STRING },
    apgar_score_1min: { type: DataTypes.STRING },
    apgar_score_5min: { type: DataTypes.STRING },
    complications: { type: DataTypes.TEXT },
    notes: { type: DataTypes.TEXT },

    // Lifecycle
    status: {
      type: DataTypes.ENUM(...NEWBORN_STATUS),
      allowNull: false,
      defaultValue: NEWBORN_STATUS[0], // "alive"
    },

    // Audit
    created_by_id: { type: DataTypes.UUID },
    updated_by_id: { type: DataTypes.UUID },
    deleted_by_id: { type: DataTypes.UUID },

    // Sequelize timestamps
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: queryInterface.sequelize.literal("CURRENT_TIMESTAMP"),
    },
    deleted_at: { type: DataTypes.DATE },
  });

  // Indexes
  await queryInterface.addIndex("newborn_records", ["organization_id"]);
  await queryInterface.addIndex("newborn_records", ["facility_id"]);
  await queryInterface.addIndex("newborn_records", ["mother_id"]);
  await queryInterface.addIndex("newborn_records", ["delivery_record_id"]);
  await queryInterface.addIndex("newborn_records", ["status"]);
}

export async function down(queryInterface) {
  await queryInterface.dropTable("newborn_records");
}
