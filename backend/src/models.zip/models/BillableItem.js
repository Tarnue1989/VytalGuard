// 📁 backend/src/models/BillableItem.js
import { DataTypes, Model } from "sequelize";
import { BILLABLE_ITEM_STATUS } from "../constants/enums.js";

export default (sequelize) => {
  class BillableItem extends Model {
    static associate(models) {
      // 🔗 Links
      BillableItem.belongsTo(models.MasterItem, { as: "masterItem", foreignKey: "master_item_id" });
      BillableItem.belongsTo(models.Organization, { as: "organization", foreignKey: "organization_id" });
      BillableItem.belongsTo(models.Facility, { as: "facility", foreignKey: "facility_id" });

      // 🔗 Optional overrides
      BillableItem.belongsTo(models.Department, { as: "department", foreignKey: "department_id" });
      BillableItem.belongsTo(models.MasterItemCategory, { as: "category", foreignKey: "category_id" });

      // 🔗 Relations
      BillableItem.hasMany(models.InvoiceItem, { as: "invoiceItems", foreignKey: "billable_item_id" });
      BillableItem.hasMany(models.BillableItemPriceHistory, { as: "priceHistory", foreignKey: "billable_item_id" });

      // 🔹 Audit
      BillableItem.belongsTo(models.User, { as: "createdBy", foreignKey: "created_by_id" });
      BillableItem.belongsTo(models.User, { as: "updatedBy", foreignKey: "updated_by_id" });
      BillableItem.belongsTo(models.User, { as: "deletedBy", foreignKey: "deleted_by_id" });
    }
  }

  BillableItem.init(
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: sequelize.literal("gen_random_uuid()"),
        primaryKey: true,
      },

      // 🔗 Tenant scope
      organization_id: { type: DataTypes.UUID, allowNull: false },
      facility_id: { type: DataTypes.UUID, allowNull: false },

      // 🔗 Master link
      master_item_id: { type: DataTypes.UUID, allowNull: false },

      // 📑 Optional overrides
      department_id: { type: DataTypes.UUID, allowNull: true },
      category_id: { type: DataTypes.UUID, allowNull: true },

      // 📑 Item details
      name: { type: DataTypes.STRING(150), allowNull: false },
      code: { type: DataTypes.STRING(100), allowNull: true }, // ✅ added for controller/search alignment
      description: { type: DataTypes.TEXT },

      // 💵 Pricing
      price: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false,
        validate: { min: 0 },
      },
      currency: { type: DataTypes.STRING(10), defaultValue: "USD" },
      taxable: { type: DataTypes.BOOLEAN, defaultValue: false },
      discountable: { type: DataTypes.BOOLEAN, defaultValue: true },
      override_allowed: { type: DataTypes.BOOLEAN, defaultValue: true },

      status: {
        type: DataTypes.ENUM(...BILLABLE_ITEM_STATUS),
        allowNull: false,
        defaultValue: BILLABLE_ITEM_STATUS[0],
      },

      // 🔹 Audit
      created_by_id: { type: DataTypes.UUID, allowNull: true },
      updated_by_id: { type: DataTypes.UUID, allowNull: true },
      deleted_by_id: { type: DataTypes.UUID, allowNull: true },
    },
    {
      sequelize,
      modelName: "BillableItem",
      tableName: "billable_items",
      underscored: true,
      paranoid: true,
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
      deletedAt: "deleted_at",
      uniqueKeys: {
        unique_price_per_scope: {
          fields: ["organization_id", "facility_id", "master_item_id"],
        },
      },
      defaultScope: {
        attributes: { exclude: ["deleted_at", "deleted_by_id"] },
      },
      scopes: {
        withDeleted: { paranoid: false },
        active: { where: { status: "active", deleted_at: null } },
        inactive: { where: { status: "inactive", deleted_at: null } },
        tenant(facilityId) {
          if (!facilityId) return {}; // safeguard for superadmin/global
          return { where: { facility_id: facilityId } };
        },
      },
      indexes: [
        { fields: ["organization_id"] },
        { fields: ["facility_id"] },
        { fields: ["status"] },
        { fields: ["name"] },
        { fields: ["code"] },       // ✅ index for code (search/autocomplete)
        { fields: ["category_id"] }, // ✅ index for category
      ],
    }
  );

  /* ============================================================
    🔁 Hooks
  ============================================================ */
  BillableItem.afterUpdate(async (item) => {
    const priceChanged = item.changed("price");
    const currencyChanged = item.changed("currency");

    if (priceChanged || currencyChanged) {
      const oldPrice = item.previous("price");
      const newPrice = item.price;
      const oldCurrency = item.previous("currency");
      const newCurrency = item.currency;

      if (oldPrice === newPrice && oldCurrency === newCurrency) return;

      // 🔹 ESM import instead of require
      const { BillableItemPriceHistory } = await import("../models/index.js");

      await BillableItemPriceHistory.create({
        billable_item_id: item.id,
        organization_id: item.organization_id,
        facility_id: item.facility_id,
        old_price: oldPrice,
        new_price: newPrice,
        old_currency: oldCurrency,
        new_currency: newCurrency,
        effective_date: new Date(),
        created_by_id: item.updated_by_id,
      });
    }
  });

  return BillableItem;
};
