// 📁 backend/src/models/FeatureModule.js
import { DataTypes, Model } from "sequelize";
import { FEATURE_MODULE_STATUS } from "../constants/enums.js";

export default (sequelize) => {
  class FeatureModule extends Model {
    static associate(models) {
      FeatureModule.belongsToMany(models.Role, {
        through: models.FeatureAccess,
        foreignKey: "module_id",
        otherKey: "role_id",
        as: "roles",
      });

      FeatureModule.hasMany(models.FeatureAccess, {
        foreignKey: "module_id",
        as: "access", // ✅ corrected alias
      });

      FeatureModule.belongsTo(models.FeatureModule, { foreignKey: "parent_id", as: "parent" });
      FeatureModule.hasMany(models.FeatureModule, { foreignKey: "parent_id", as: "children" });

      FeatureModule.belongsTo(models.User, { foreignKey: "created_by_id", as: "createdBy" });
      FeatureModule.belongsTo(models.User, { foreignKey: "updated_by_id", as: "updatedBy" });
      FeatureModule.belongsTo(models.User, { foreignKey: "deleted_by_id", as: "deletedBy" });
    }
  }

  FeatureModule.init(
    {
      id: { type: DataTypes.UUID, primaryKey: true, defaultValue: DataTypes.UUIDV4 },
      name: { type: DataTypes.STRING, allowNull: false },
      key: { type: DataTypes.STRING, allowNull: false, unique: true },
      icon: { type: DataTypes.STRING },
      category: { type: DataTypes.STRING },
      description: { type: DataTypes.TEXT },
      tags: { type: DataTypes.ARRAY(DataTypes.STRING), defaultValue: [] },
      visibility: { type: DataTypes.ENUM("public", "private", "hidden"), allowNull: false, defaultValue: "public" },
      enabled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
      status: { type: DataTypes.ENUM(...FEATURE_MODULE_STATUS), allowNull: false, defaultValue: FEATURE_MODULE_STATUS[0] },
      route: { type: DataTypes.STRING, validate: { is: /^[a-zA-Z0-9_\-/\.]*$/ } },
      parent_id: { type: DataTypes.UUID },
      created_by_id: { type: DataTypes.UUID },
      updated_by_id: { type: DataTypes.UUID },
      deleted_by_id: { type: DataTypes.UUID },
    },
    {
      sequelize,
      modelName: "FeatureModule",
      tableName: "feature_modules",
      underscored: true,
      paranoid: true,
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
      deletedAt: "deleted_at",
      defaultScope: { attributes: { exclude: ["deleted_at", "deleted_by_id"] } },
      scopes: {
        withDeleted: { paranoid: false },
        active: { where: { status: "active" } },
        inactive: { where: { status: "inactive" } },
      },
    }
  );

  return FeatureModule;
};
